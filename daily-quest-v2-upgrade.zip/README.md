# DailyQ v2

Daily quests, streaks, mood check-ins, meal logging and journaling — rebuilt as a
single Next.js (App Router) + PostgreSQL (Drizzle) app.

## What changed from v1

| Area | v1 | v2 |
|---|---|---|
| Architecture | Fastify + Prisma API, Vite SPA, 1,200-line `DailyTracker.jsx`, client cache, debounced whole-document saves | One Next.js app: Server Components + Server Actions, small client islands |
| Data model | One `quest_data` row with 10 JSON blobs (last-write-wins, unbounded arrays) | Normalized tables: `quests`, `completions`, `mood_entries`, `journal_entries`, `meals`, `daily_activity`, `streak_events`, `sessions`, `ai_usage` |
| Streak / XP / levels | Computed on the client at page load, stored as mutable counters, freeze decided by a modal | Derived server-side from `completions` on every request; freezes auto-applied and recorded; +1 freeze every 7-day milestone (cap 3) |
| Dates | `toISOString()` (UTC) vs "local day" comments → wrong day near midnight | User timezone stored; "today" computed server-side with `Intl.DateTimeFormat` |
| Auth | Google ID token + hand-rolled JWT/refresh rotation | Google OAuth (server-side authorization-code flow) **and** email/password; DB-backed HttpOnly session cookie |
| AI | OpenAI SDK, `gpt-4o`, strict `json_schema` (OpenAI-only) | **OpenRouter** via `fetch` (`OPENROUTER_API_KEY`, any model), JSON mode + tolerant parsing, deterministic fallbacks |
| Removed | Premium/trial gating, photo uploads + Railway volume + signed URLs, Base44/Telegram leftovers, `i18n.js` (36 KB), `UserDataCache`, `PremiumModal`, `StreakFreezeModal`, duplicated `sanitizeQuestData` | — |
| Deploy | `prisma migrate deploy` step, 1-replica volume pin | Idempotent schema bootstrap on server start (`src/instrumentation.ts`), stateless, `railway.json` health check on `/api/health` |

## Running locally

```bash
npm install
cp .env.example .env      # fill DATABASE_URL (+ optional Google / OpenRouter keys)
npm run dev               # tables are created automatically on first start
```

`npx drizzle-kit push` also works if you prefer to sync the schema explicitly.

## Deploying to Railway

1. Add a PostgreSQL plugin; Railway injects `DATABASE_URL`.
2. Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` and (for custom domains) `APP_URL`.
   In Google Cloud Console add the redirect URI `https://<domain>/api/auth/google/callback`.
3. Set `OPENROUTER_API_KEY` (and optionally `OPENROUTER_MODEL`).
4. Push. `railway.json` builds with `npm run build`, starts with `npm run start`,
   and health-checks `/api/health`. The schema is created on boot.

## Project layout

```
src/app/(auth)/login          Sign-in page (Google + email/password)
src/app/(app)/today           Dashboard: streak, level, 6 category cards × 3 tiers, mood, fuel, journal
src/app/(app)/history         Calendar heatmap + per-day detail
src/app/(app)/stats           30-day XP chart, life balance, mood trend, level path
src/app/(app)/profile         Settings, quest editor (+AI suggest), export, reset, delete
src/app/(app)/onboarding      6 questions → AI-generated quest board → review → save
src/app/actions/*             Server Actions (auth, today, profile/onboarding)
src/app/api/auth/google/*     OAuth start + callback
src/app/api/export            JSON export
src/lib/game.ts               Pure game rules: levels, category levels, streak derivation
src/lib/data.ts               Dashboard/stats queries, streak sync (auto-freeze)
src/lib/ai.ts                 OpenRouter client + fallbacks (quests, meal macros, suggestions, motivation)
src/lib/auth.ts               Sessions, scrypt passwords, Google code exchange
src/db/schema.ts              Drizzle schema · src/db/migrate.ts idempotent bootstrap
```

## Game rules

- Each category has three quests: tier 1 (+1 XP), tier 2 (+2 XP), tier 3 (+3 XP). Any can be completed each day.
- Player level thresholds: 0 / 10 / 25 / 50 / 100 / 200 / 350 / 550 / 800 / 1100 XP.
- Category level = `floor(categoryXP / 10) + 1`.
- Streak = consecutive local days with ≥1 completion. A single missed day is bridged automatically by a freeze (if available) and recorded in `streak_events`. Two missed days end the streak.
- New users start with 1 freeze; +1 at every 7-day streak milestone, max 3.

## Migrating v1 data

v1's `quest_data` JSON maps cleanly: `completion_history` → `completions`,
`mood_log` → `mood_entries`, `journal_entries` → `journal_entries`,
`meal_history` → `meals`, `calories_burned` → `daily_activity`, `quest_data` → `quests`.
Users match on `google_sub` / `email`. A one-off import script can read the old
table and insert rows; streaks, XP and levels are derived, so nothing else needs copying.
