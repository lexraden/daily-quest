import {
  pgTable,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
  index,
  real,
} from "drizzle-orm/pg-core";

/** Six fixed life areas, unchanged from v1. */
export const CATEGORIES = ["health", "mind", "work", "money", "love", "friends"] as const;
export type Category = (typeof CATEGORIES)[number];

export const users = pgTable(
  "users",
  {
    id: text("id").primaryKey(),
    email: text("email").notNull(),
    name: text("name"),
    avatarUrl: text("avatar_url"),
    googleSub: text("google_sub"),
    passwordHash: text("password_hash"),
    timezone: text("timezone").notNull().default("UTC"),
    locale: text("locale").notNull().default("en"),
    onboardedAt: timestamp("onboarded_at", { withTimezone: true }),
    onboardingAnswers: jsonb("onboarding_answers").$type<Record<string, string>>().notNull().default({}),
    streakFreezes: integer("streak_freezes").notNull().default(1),
    dailyCalorieGoal: integer("daily_calorie_goal").notNull().default(2000),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_email_idx").on(t.email), uniqueIndex("users_google_sub_idx").on(t.googleSub)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("sessions_token_hash_idx").on(t.tokenHash), index("sessions_user_idx").on(t.userId)],
);

/** Three tiers (1..3) per category per user. XP awarded = tier. */
export const quests = pgTable(
  "quests",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    category: text("category").notNull(),
    tier: integer("tier").notNull(),
    emoji: text("emoji").notNull().default("✨"),
    name: text("name").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("quests_user_cat_tier_idx").on(t.userId, t.category, t.tier)],
);

/** One row per completed quest per local day. Source of truth for streaks, XP, levels. */
export const completions = pgTable(
  "completions",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    day: text("day").notNull(), // YYYY-MM-DD in the user's timezone
    category: text("category").notNull(),
    tier: integer("tier").notNull(),
    questName: text("quest_name").notNull(),
    xp: integer("xp").notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("completions_unique_idx").on(t.userId, t.day, t.category, t.tier),
    index("completions_user_day_idx").on(t.userId, t.day),
  ],
);

export const moodEntries = pgTable(
  "mood_entries",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    day: text("day").notNull(),
    score: integer("score").notNull(), // 1..5
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("mood_user_day_idx").on(t.userId, t.day)],
);

export const journalEntries = pgTable(
  "journal_entries",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    day: text("day").notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("journal_user_day_idx").on(t.userId, t.day)],
);

export const meals = pgTable(
  "meals",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    day: text("day").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    calories: integer("calories").notNull().default(0),
    protein: real("protein").notNull().default(0),
    fat: real("fat").notNull().default(0),
    carbs: real("carbs").notNull().default(0),
    aiEstimated: boolean("ai_estimated").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("meals_user_day_idx").on(t.userId, t.day)],
);

/** Calories burned per day (manual entry, replaces v1 calories_burned JSON). */
export const dailyActivity = pgTable(
  "daily_activity",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    day: text("day").notNull(),
    caloriesBurned: integer("calories_burned").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("activity_user_day_idx").on(t.userId, t.day)],
);

/** A recorded freeze covering a missed day, plus freeze awards, so history is auditable. */
export const streakEvents = pgTable(
  "streak_events",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    day: text("day").notNull(),
    kind: text("kind").notNull(), // 'freeze_used' | 'freeze_awarded'
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("streak_events_unique_idx").on(t.userId, t.day, t.kind)],
);

/** Monthly AI spend guard, kept from v1. */
export const aiUsage = pgTable(
  "ai_usage",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    period: text("period").notNull(), // YYYY-MM
    calls: integer("calls").notNull().default(0),
  },
  (t) => [uniqueIndex("ai_usage_user_period_idx").on(t.userId, t.period)],
);

export type User = typeof users.$inferSelect;
export type Quest = typeof quests.$inferSelect;
export type Completion = typeof completions.$inferSelect;
export type Meal = typeof meals.$inferSelect;
