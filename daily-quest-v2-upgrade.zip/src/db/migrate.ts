import { sql } from "drizzle-orm";
import { db } from "@/db";

/**
 * Idempotent bootstrap of the v2 schema. Runs once at server start (see
 * src/instrumentation.ts) so a fresh Railway deploy needs no manual step and no
 * dev-only tooling at runtime. Every statement is safe to re-run, and it stays
 * compatible with `npx drizzle-kit push` for local development.
 */
const STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS "users" (
    "id" text PRIMARY KEY,
    "email" text NOT NULL,
    "name" text,
    "avatar_url" text,
    "google_sub" text,
    "password_hash" text,
    "timezone" text NOT NULL DEFAULT 'UTC',
    "locale" text NOT NULL DEFAULT 'en',
    "onboarded_at" timestamptz,
    "onboarding_answers" jsonb NOT NULL DEFAULT '{}'::jsonb,
    "streak_freezes" integer NOT NULL DEFAULT 1,
    "daily_calorie_goal" integer NOT NULL DEFAULT 2000,
    "created_at" timestamptz NOT NULL DEFAULT now(),
    "updated_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "users_email_idx" ON "users" ("email")`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "users_google_sub_idx" ON "users" ("google_sub")`,

  `CREATE TABLE IF NOT EXISTS "sessions" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "token_hash" text NOT NULL,
    "expires_at" timestamptz NOT NULL,
    "created_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "sessions_token_hash_idx" ON "sessions" ("token_hash")`,
  `CREATE INDEX IF NOT EXISTS "sessions_user_idx" ON "sessions" ("user_id")`,

  `CREATE TABLE IF NOT EXISTS "quests" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "category" text NOT NULL,
    "tier" integer NOT NULL,
    "emoji" text NOT NULL DEFAULT '✨',
    "name" text NOT NULL,
    "created_at" timestamptz NOT NULL DEFAULT now(),
    "updated_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "quests_user_cat_tier_idx" ON "quests" ("user_id","category","tier")`,

  `CREATE TABLE IF NOT EXISTS "completions" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "day" text NOT NULL,
    "category" text NOT NULL,
    "tier" integer NOT NULL,
    "quest_name" text NOT NULL,
    "xp" integer NOT NULL,
    "completed_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "completions_unique_idx" ON "completions" ("user_id","day","category","tier")`,
  `CREATE INDEX IF NOT EXISTS "completions_user_day_idx" ON "completions" ("user_id","day")`,

  `CREATE TABLE IF NOT EXISTS "mood_entries" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "day" text NOT NULL,
    "score" integer NOT NULL,
    "note" text,
    "created_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "mood_user_day_idx" ON "mood_entries" ("user_id","day")`,

  `CREATE TABLE IF NOT EXISTS "journal_entries" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "day" text NOT NULL,
    "content" text NOT NULL,
    "created_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE INDEX IF NOT EXISTS "journal_user_day_idx" ON "journal_entries" ("user_id","day")`,

  `CREATE TABLE IF NOT EXISTS "meals" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "day" text NOT NULL,
    "name" text NOT NULL,
    "description" text,
    "calories" integer NOT NULL DEFAULT 0,
    "protein" real NOT NULL DEFAULT 0,
    "fat" real NOT NULL DEFAULT 0,
    "carbs" real NOT NULL DEFAULT 0,
    "ai_estimated" boolean NOT NULL DEFAULT false,
    "created_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE INDEX IF NOT EXISTS "meals_user_day_idx" ON "meals" ("user_id","day")`,

  `CREATE TABLE IF NOT EXISTS "daily_activity" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "day" text NOT NULL,
    "calories_burned" integer NOT NULL DEFAULT 0,
    "updated_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "activity_user_day_idx" ON "daily_activity" ("user_id","day")`,

  `CREATE TABLE IF NOT EXISTS "streak_events" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "day" text NOT NULL,
    "kind" text NOT NULL,
    "created_at" timestamptz NOT NULL DEFAULT now()
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "streak_events_unique_idx" ON "streak_events" ("user_id","day","kind")`,

  `CREATE TABLE IF NOT EXISTS "ai_usage" (
    "id" text PRIMARY KEY,
    "user_id" text NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "period" text NOT NULL,
    "calls" integer NOT NULL DEFAULT 0
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "ai_usage_user_period_idx" ON "ai_usage" ("user_id","period")`,
];

export async function runMigrations(): Promise<void> {
  for (const statement of STATEMENTS) {
    await db.execute(sql.raw(statement));
  }
}
