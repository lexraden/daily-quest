/**
 * Runs once when the Node server boots (production and dev). Creates any missing
 * tables so a Railway deploy is self-contained. Set SKIP_MIGRATIONS=1 to opt out.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  if (process.env.SKIP_MIGRATIONS === "1") return;
  if (!process.env.DATABASE_URL) return;
  try {
    const { runMigrations } = await import("./db/migrate");
    await runMigrations();
    console.log("[dailyq] schema ready");
  } catch (err) {
    console.error("[dailyq] schema bootstrap failed", err);
  }
}
