import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { completions, journalEntries, meals, moodEntries, quests, streakEvents, dailyActivity } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Full JSON export of the signed-in user's data. */
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "unauthenticated" }, { status: 401 });

  const [q, c, m, j, me, s, a] = await Promise.all([
    db.select().from(quests).where(eq(quests.userId, user.id)),
    db.select().from(completions).where(eq(completions.userId, user.id)).orderBy(asc(completions.day)),
    db.select().from(moodEntries).where(eq(moodEntries.userId, user.id)).orderBy(asc(moodEntries.day)),
    db.select().from(journalEntries).where(eq(journalEntries.userId, user.id)).orderBy(asc(journalEntries.day)),
    db.select().from(meals).where(eq(meals.userId, user.id)).orderBy(asc(meals.day)),
    db.select().from(streakEvents).where(eq(streakEvents.userId, user.id)).orderBy(asc(streakEvents.day)),
    db.select().from(dailyActivity).where(eq(dailyActivity.userId, user.id)).orderBy(asc(dailyActivity.day)),
  ]);

  const body = {
    version: 2,
    exportedAt: new Date().toISOString(),
    profile: { email: user.email, name: user.name, timezone: user.timezone, locale: user.locale, streakFreezes: user.streakFreezes, dailyCalorieGoal: user.dailyCalorieGoal, onboardingAnswers: user.onboardingAnswers },
    quests: q,
    completions: c,
    moods: m,
    journal: j,
    meals: me,
    streakEvents: s,
    activity: a,
  };
  return new Response(JSON.stringify(body, null, 2), {
    headers: {
      "content-type": "application/json",
      "content-disposition": `attachment; filename="dailyq-export-${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}
