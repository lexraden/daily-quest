import { cookies } from "next/headers";
import { NextResponse, type NextRequest } from "next/server";
import { appBaseUrl, browserTimezone, createSession, exchangeGoogleCode, googleConfigured, upsertGoogleUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Step 2: verify state, exchange the code server-side, create a session. */
export async function GET(req: NextRequest) {
  const base = await appBaseUrl();
  const fail = (code: string) => NextResponse.redirect(`${base}/login?error=${code}`);
  if (!googleConfigured()) return fail("google_not_configured");

  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const jar = await cookies();
  const expected = jar.get("dq_oauth_state")?.value;
  jar.delete("dq_oauth_state");

  if (url.searchParams.get("error")) return fail("google_denied");
  if (!code || !state || !expected || state !== expected) return fail("google_state");

  try {
    const profile = await exchangeGoogleCode(code, `${base}/api/auth/google/callback`);
    if (profile.email_verified === false) return fail("google_unverified");
    const tz = await browserTimezone("UTC");
    const user = await upsertGoogleUser(profile, tz);
    await createSession(user.id);
    return NextResponse.redirect(`${base}${user.onboardedAt ? "/today" : "/onboarding"}`);
  } catch (err) {
    console.error("[auth] google callback", err);
    return fail("google_failed");
  }
}
