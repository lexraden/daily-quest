import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { appBaseUrl, googleConfigured } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Step 1: send the user to Google's consent screen with a CSRF `state`. */
export async function GET() {
  const base = await appBaseUrl();
  if (!googleConfigured()) {
    return NextResponse.redirect(`${base}/login?error=google_not_configured`);
  }
  const state = randomBytes(16).toString("hex");
  const jar = await cookies();
  jar.set("dq_oauth_state", state, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 600,
  });

  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: `${base}/api/auth/google/callback`,
    response_type: "code",
    scope: "openid email profile",
    state,
    access_type: "online",
    prompt: "select_account",
  });
  return NextResponse.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
}
