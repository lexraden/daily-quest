import { requireUser } from "@/lib/auth";
import { aiConfigured } from "@/lib/ai";
import { OnboardingForm } from "@/components/OnboardingForm";

export const dynamic = "force-dynamic";

export default async function OnboardingPage() {
  const user = await requireUser();
  return (
    <main className="space-y-4">
      <header>
        <h1 className="text-2xl font-bold">{user.onboardedAt ? "Rebuild your quests" : `Welcome${user.name ? `, ${user.name.split(" ")[0]}` : ""} 👋`}</h1>
        <p className="mt-1 text-sm text-muted">Answer six quick questions and we&apos;ll turn them into daily quests across every area of life.</p>
      </header>
      <OnboardingForm initialAnswers={user.onboardingAnswers ?? {}} initialLocale={user.locale} aiEnabled={aiConfigured()} />
    </main>
  );
}
