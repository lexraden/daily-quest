import { requireUser } from "@/lib/auth";
import { getStats } from "@/lib/data";
import { formatDayLabel } from "@/lib/dates";
import { CATEGORIES, CATEGORY_META, categoryLevel, LEVELS } from "@/lib/game";
import { MOODS } from "@/components/MoodCheckIn";

export const dynamic = "force-dynamic";

export default async function StatsPage() {
  const user = await requireUser();
  const s = await getStats(user);
  const maxXp = Math.max(1, ...s.last30.map((d) => d.xp));
  const weekXp = s.last7.reduce((a, d) => a + d.xp, 0);
  const weekCount = s.last7.reduce((a, d) => a + d.count, 0);
  const catMax = Math.max(1, ...CATEGORIES.map((c) => s.totals.byCategory[c].xp));
  const avgMood = s.moods.length ? Math.round((s.moods.reduce((a, m) => a + m.score, 0) / s.moods.length) * 10) / 10 : null;

  return (
    <main className="space-y-4">
      <h1 className="text-2xl font-bold">Stats</h1>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Tile label="Current streak" value={`${s.streak.current}🔥`} />
        <Tile label="Longest streak" value={`${s.streak.longest}`} />
        <Tile label="Total XP" value={`${s.totals.totalXp}`} />
        <Tile label="Quests done" value={`${s.totals.totalCount}`} />
        <Tile label="Active days" value={`${s.activeDaysTotal}`} />
        <Tile label="Avg / active day" value={`${s.avgPerActiveDay}`} />
        <Tile label="This week" value={`${weekCount} · ${weekXp} XP`} />
        <Tile label="Freezes" value={`🧊 ${s.streak.freezes}`} />
      </section>

      <section className="card p-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Last 30 days</h2>
          <span className="text-xs text-muted">best: {s.bestDay.xp} XP on {formatDayLabel(s.bestDay.day)}</span>
        </div>
        <div className="flex h-28 items-end gap-[3px]">
          {s.last30.map((d) => (
            <div key={d.day} className="group relative flex-1">
              <div className="w-full rounded-t bg-gradient-to-t from-accent to-accent-2 transition-all" style={{ height: `${Math.max(d.xp > 0 ? 6 : 2, (d.xp / maxXp) * 100)}%`, opacity: d.xp > 0 ? 1 : 0.25 }} />
              <div className="pointer-events-none absolute -top-7 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded bg-black/80 px-1.5 py-0.5 text-[10px] group-hover:block">{formatDayLabel(d.day)} · {d.xp} XP</div>
            </div>
          ))}
        </div>
        <div className="mt-1 flex justify-between text-[10px] text-muted"><span>{formatDayLabel(s.last30[0].day)}</span><span>Today</span></div>
      </section>

      <section className="card p-4">
        <h2 className="mb-3 font-semibold">Life balance</h2>
        <div className="space-y-2.5">
          {CATEGORIES.map((c) => {
            const meta = CATEGORY_META[c];
            const xp = s.totals.byCategory[c].xp;
            const lvl = categoryLevel(xp);
            return (
              <div key={c}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="font-medium" style={{ color: meta.color }}>{meta.emoji} {meta.name} · Lv {lvl.level}</span>
                  <span className="text-muted">{xp} XP · {s.totals.byCategory[c].count} done</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-panel-2">
                  <div className="h-full rounded-full" style={{ width: `${(xp / catMax) * 100}%`, background: meta.color }} />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="card p-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Mood · 30 days</h2>
          {avgMood !== null && <span className="text-xs text-muted">avg {avgMood}/5</span>}
        </div>
        {s.moods.length === 0 ? (
          <p className="text-sm text-muted">No mood check-ins yet.</p>
        ) : (
          <div className="flex h-16 items-end gap-1">
            {s.moods.map((m) => (
              <div key={m.day} className="flex flex-1 flex-col items-center gap-0.5" title={`${formatDayLabel(m.day)} · ${MOODS[m.score - 1]?.label}`}>
                <span className="text-xs">{MOODS[m.score - 1]?.emoji}</span>
                <div className="w-full rounded-t bg-accent-2/70" style={{ height: `${(m.score / 5) * 40}px` }} />
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="card p-4">
        <h2 className="mb-3 font-semibold">Level path</h2>
        <ol className="grid grid-cols-5 gap-2 text-center text-[11px]">
          {LEVELS.map((l) => {
            const reached = s.totals.totalXp >= l.threshold;
            return (
              <li key={l.level} className={`rounded-xl border px-1 py-2 ${reached ? "border-accent/50 bg-accent/15" : "border-line bg-panel-2 opacity-60"}`}>
                <div className="text-lg">{l.icon}</div>
                <div className="font-medium">{l.name}</div>
                <div className="text-muted">{l.threshold} XP</div>
              </li>
            );
          })}
        </ol>
      </section>
    </main>
  );
}

function Tile({ label, value }: { label: string; value: string }) {
  return (
    <div className="card px-4 py-3">
      <div className="text-lg font-bold">{value}</div>
      <div className="text-[11px] uppercase tracking-wide text-muted">{label}</div>
    </div>
  );
}
