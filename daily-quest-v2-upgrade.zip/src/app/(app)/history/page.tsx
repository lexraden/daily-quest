import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getMonthData } from "@/lib/data";
import { daysInMonth, formatDayLabel, isValidDay, todayIn, weekdayMondayFirst } from "@/lib/dates";
import { CATEGORY_META, type Category } from "@/lib/game";
import { MOODS } from "@/components/MoodCheckIn";

export const dynamic = "force-dynamic";

export default async function HistoryPage({ searchParams }: { searchParams: Promise<{ month?: string; day?: string }> }) {
  const user = await requireUser();
  const today = todayIn(user.timezone);
  const sp = await searchParams;
  const month = sp.month && /^\d{4}-\d{2}$/.test(sp.month) ? sp.month : today.slice(0, 7);
  const selected = sp.day && isValidDay(sp.day) ? sp.day : today.startsWith(month) ? today : `${month}-01`;
  const data = await getMonthData(user, month);

  const [y, m] = month.split("-").map(Number);
  const count = daysInMonth(y, m);
  const firstOffset = weekdayMondayFirst(`${month}-01`);
  const prev = new Date(Date.UTC(y, m - 2, 1)).toISOString().slice(0, 7);
  const next = new Date(Date.UTC(y, m, 1)).toISOString().slice(0, 7);
  const monthLabel = new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(y, m - 1, 1)));

  const perDay = new Map<string, { xp: number; count: number; cats: Set<string> }>();
  for (const c of data.completions) {
    const e = perDay.get(c.day) ?? { xp: 0, count: 0, cats: new Set() };
    e.xp += c.xp;
    e.count += 1;
    e.cats.add(c.category);
    perDay.set(c.day, e);
  }
  const frozen = new Set(data.events.filter((e) => e.kind === "freeze_used").map((e) => e.day));
  const moodByDay = new Map(data.moods.map((mo) => [mo.day, mo]));

  const dayComps = data.completions.filter((c) => c.day === selected);
  const dayMeals = data.meals.filter((x) => x.day === selected);
  const dayJournal = data.journal.filter((x) => x.day === selected);
  const dayMood = moodByDay.get(selected);
  const monthXp = data.completions.reduce((s, c) => s + c.xp, 0);
  const activeDays = perDay.size;

  return (
    <main className="space-y-4">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">History</h1>
        <div className="text-xs text-muted">{activeDays} active days · {monthXp} XP</div>
      </header>

      <section className="card p-4">
        <div className="mb-3 flex items-center justify-between">
          <Link href={`/history?month=${prev}`} className="btn-ghost px-3 py-1.5">←</Link>
          <div className="font-semibold">{monthLabel}</div>
          <Link href={`/history?month=${next}`} className="btn-ghost px-3 py-1.5" aria-disabled={next > today.slice(0, 7)}>→</Link>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-[10px] uppercase text-muted">
          {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => <div key={d}>{d}</div>)}
        </div>
        <div className="mt-1 grid grid-cols-7 gap-1">
          {Array.from({ length: firstOffset }).map((_, i) => <div key={`e${i}`} />)}
          {Array.from({ length: count }, (_, i) => {
            const day = `${month}-${String(i + 1).padStart(2, "0")}`;
            const e = perDay.get(day);
            const isFuture = day > today;
            const intensity = e ? Math.min(1, e.count / 6) : 0;
            const mood = moodByDay.get(day);
            return (
              <Link
                key={day}
                href={`/history?month=${month}&day=${day}`}
                className={`relative flex aspect-square flex-col items-center justify-center rounded-lg border text-xs transition ${selected === day ? "border-accent" : "border-transparent"} ${isFuture ? "opacity-30" : "hover:border-line"}`}
                style={{ background: e ? `rgba(124,108,242,${0.15 + intensity * 0.7})` : frozen.has(day) ? "rgba(0,206,201,0.25)" : "#1c1c2b" }}
              >
                <span className={`font-medium ${day === today ? "text-accent-2" : ""}`}>{i + 1}</span>
                {mood && <span className="absolute bottom-0.5 text-[9px]">{MOODS[mood.score - 1]?.emoji}</span>}
                {frozen.has(day) && !e && <span className="absolute right-0.5 top-0.5 text-[9px]">🧊</span>}
              </Link>
            );
          })}
        </div>
      </section>

      <section className="card p-4">
        <h2 className="font-semibold">{formatDayLabel(selected, { weekday: "long", month: "long", day: "numeric" })}</h2>
        {dayMood && <div className="mt-2 text-sm">{MOODS[dayMood.score - 1]?.emoji} {MOODS[dayMood.score - 1]?.label}{dayMood.note ? ` — ${dayMood.note}` : ""}</div>}
        {frozen.has(selected) && <div className="mt-2 text-sm text-accent-2">🧊 Streak freeze used on this day</div>}

        <div className="mt-3">
          <div className="label">Quests · {dayComps.reduce((s, c) => s + c.xp, 0)} XP</div>
          {dayComps.length === 0 ? (
            <p className="text-sm text-muted">No quests completed.</p>
          ) : (
            <ul className="space-y-1">
              {dayComps.map((c) => {
                const meta = CATEGORY_META[c.category as Category];
                return (
                  <li key={c.id} className="flex items-center gap-2 rounded-lg bg-panel-2 px-3 py-1.5 text-sm">
                    <span>{meta?.emoji}</span>
                    <span className="flex-1">{c.questName}</span>
                    <span className="text-xs text-muted">+{c.xp}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {dayMeals.length > 0 && (
          <div className="mt-3">
            <div className="label">Meals · {dayMeals.reduce((s, x) => s + x.calories, 0)} kcal</div>
            <ul className="space-y-1">
              {dayMeals.map((x) => (
                <li key={x.id} className="flex justify-between rounded-lg bg-panel-2 px-3 py-1.5 text-sm"><span>{x.name}</span><span className="text-xs text-muted">{x.calories} kcal</span></li>
              ))}
            </ul>
          </div>
        )}

        {dayJournal.length > 0 && (
          <div className="mt-3">
            <div className="label">Journal</div>
            <ul className="space-y-1">
              {dayJournal.map((x) => <li key={x.id} className="whitespace-pre-wrap rounded-lg bg-panel-2 px-3 py-2 text-sm">{x.content}</li>)}
            </ul>
          </div>
        )}
      </section>
    </main>
  );
}
