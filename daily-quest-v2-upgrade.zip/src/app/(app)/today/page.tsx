import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { getDashboard } from "@/lib/data";
import { aiConfigured, dailyMotivation, type Lang } from "@/lib/ai";
import { formatDayLabel } from "@/lib/dates";
import { CelebrateProvider } from "@/components/Celebrate";
import { QuestCategoryCard } from "@/components/QuestCategoryCard";
import { MoodCheckIn } from "@/components/MoodCheckIn";
import { FuelPanel } from "@/components/FuelPanel";
import { JournalPanel } from "@/components/JournalPanel";

export const dynamic = "force-dynamic";

export default async function TodayPage() {
  const user = await requireUser();
  if (!user.onboardedAt) redirect("/onboarding");
  const d = await getDashboard(user);
  const motivation = await dailyMotivation(user.id, { name: user.name, streak: d.streak.current, level: d.level.name, doneToday: d.doneToday, lang: user.locale as Lang });
  const totalQuests = d.categories.reduce((s, c) => s + c.quests.length, 0);

  return (
    <CelebrateProvider>
      <main className="space-y-4">
        <header className="card relative overflow-hidden p-5">
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-accent/20 blur-3xl" />
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-xs uppercase tracking-wide text-muted">{formatDayLabel(d.today, { weekday: "long", month: "long", day: "numeric" })}</div>
              <h1 className="mt-1 text-2xl font-bold">Hey{user.name ? `, ${user.name.split(" ")[0]}` : ""} {d.level.icon}</h1>
              <p className="mt-1 text-sm text-muted">{motivation}</p>
            </div>
            <div className="shrink-0 text-right">
              <div className="text-3xl font-black leading-none">{d.streak.current}<span className="ml-1 text-base">🔥</span></div>
              <div className="text-[11px] text-muted">day streak</div>
              <div className="mt-1 text-[11px] text-muted">🧊 {d.streak.freezes} freeze{d.streak.freezes === 1 ? "" : "s"}</div>
            </div>
          </div>
          {d.streak.freezeAppliedFor && (
            <div className="mt-3 rounded-lg border border-accent-2/30 bg-accent-2/10 px-3 py-2 text-xs text-accent-2">
              🧊 A streak freeze covered {formatDayLabel(d.streak.freezeAppliedFor)} — your streak is safe.
            </div>
          )}
          {!d.streak.activeToday && d.streak.current > 0 && (
            <div className="mt-3 rounded-lg border border-yellow-500/30 bg-yellow-500/10 px-3 py-2 text-xs text-yellow-200">
              Complete one quest today to keep your {d.streak.current}-day streak alive.
            </div>
          )}
          <div className="mt-4">
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="font-semibold">Lv {d.level.level} · {d.level.name}</span>
              <span className="text-muted">{d.totalXp} XP{d.level.next ? ` · ${d.level.remaining} to ${d.level.next.name}` : " · max level"}</span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-panel-2">
              <div className="h-full rounded-full bg-gradient-to-r from-accent to-accent-2 transition-all" style={{ width: `${d.level.progress}%` }} />
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
            <div className="rounded-xl bg-panel-2 py-2"><div className="text-base font-bold">{d.doneToday}/{totalQuests}</div><div className="text-muted">today</div></div>
            <div className="rounded-xl bg-panel-2 py-2"><div className="text-base font-bold">+{d.xpToday}</div><div className="text-muted">XP today</div></div>
            <div className="rounded-xl bg-panel-2 py-2"><div className="text-base font-bold">{d.totalCompleted}</div><div className="text-muted">all time</div></div>
          </div>
        </header>

        <MoodCheckIn initial={d.mood ? { score: d.mood.score, note: d.mood.note } : null} />

        <div className="grid gap-3 sm:grid-cols-2">
          {d.categories.map((c) => (
            <QuestCategoryCard key={c.category} category={c.category} quests={c.quests.map((q) => ({ tier: q.tier, emoji: q.emoji, name: q.name, done: q.done }))} level={c.level} xp={c.xp} />
          ))}
        </div>

        <FuelPanel
          meals={d.meals.map((m) => ({ id: m.id, name: m.name, calories: m.calories, protein: m.protein, fat: m.fat, carbs: m.carbs, aiEstimated: m.aiEstimated }))}
          caloriesBurned={d.caloriesBurned}
          goal={user.dailyCalorieGoal}
          aiEnabled={aiConfigured()}
        />

        <JournalPanel entries={d.journal.map((j) => ({ id: j.id, content: j.content, createdAt: j.createdAt.toISOString() }))} />
      </main>
    </CelebrateProvider>
  );
}
