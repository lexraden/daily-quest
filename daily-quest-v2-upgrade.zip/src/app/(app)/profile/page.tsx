import { requireUser } from "@/lib/auth";
import { getQuests, getXpTotals, syncStreak } from "@/lib/data";
import { aiConfigured } from "@/lib/ai";
import { levelForXp } from "@/lib/game";
import { ProfileForms } from "@/components/ProfileForms";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const user = await requireUser();
  const [quests, totals, streak] = await Promise.all([getQuests(user.id), getXpTotals(user.id), syncStreak(user)]);
  const level = levelForXp(totals.totalXp);

  return (
    <main className="space-y-4">
      <header className="card flex items-center gap-4 p-5">
        {user.avatarUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={user.avatarUrl} alt="" className="h-16 w-16 rounded-2xl object-cover" referrerPolicy="no-referrer" />
        ) : (
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-accent/20 text-3xl">{level.icon}</div>
        )}
        <div className="min-w-0">
          <h1 className="truncate text-xl font-bold">{user.name ?? user.email.split("@")[0]}</h1>
          <div className="text-sm text-muted">Lv {level.level} {level.name} · {totals.totalXp} XP</div>
          <div className="text-sm text-muted">🔥 {streak.current} day streak · 🧊 {streak.freezes} freeze{streak.freezes === 1 ? "" : "s"}</div>
        </div>
      </header>
      <ProfileForms
        user={{ name: user.name, email: user.email, timezone: user.timezone, locale: user.locale, dailyCalorieGoal: user.dailyCalorieGoal, hasPassword: Boolean(user.passwordHash), hasGoogle: Boolean(user.googleSub) }}
        quests={quests.map((q) => ({ category: q.category, tier: q.tier, emoji: q.emoji, name: q.name }))}
        aiEnabled={aiConfigured()}
      />
      <p className="pb-2 text-center text-[11px] text-muted">DailyQ v2 · {aiConfigured() ? "AI via OpenRouter" : "AI disabled (no OPENROUTER_API_KEY)"}</p>
    </main>
  );
}
