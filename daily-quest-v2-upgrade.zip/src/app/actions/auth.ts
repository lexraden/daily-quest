"use server";

import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, destroySession, hashPassword, newId, verifyPassword } from "@/lib/auth";
import { isValidTimezone } from "@/lib/dates";

export type AuthState = { error?: string } | undefined;

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function registerAction(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const name = String(formData.get("name") ?? "").trim().slice(0, 80);
  const tzRaw = String(formData.get("timezone") ?? "UTC");
  const timezone = isValidTimezone(tzRaw) ? tzRaw : "UTC";

  if (!emailRe.test(email)) return { error: "Enter a valid email address." };
  if (password.length < 8) return { error: "Password must be at least 8 characters." };

  const existing = await db.select({ id: users.id, passwordHash: users.passwordHash }).from(users).where(eq(users.email, email)).limit(1);
  if (existing[0]) {
    return { error: existing[0].passwordHash ? "That email is already registered. Sign in instead." : "That email uses Google sign-in. Continue with Google." };
  }

  const [user] = await db
    .insert(users)
    .values({ id: newId(), email, name: name || null, passwordHash: hashPassword(password), timezone })
    .returning();
  await createSession(user.id);
  redirect("/onboarding");
}

export async function loginAction(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const tzRaw = String(formData.get("timezone") ?? "");

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return { error: user && !user.passwordHash ? "This account uses Google sign-in." : "Wrong email or password." };
  }
  if (tzRaw && isValidTimezone(tzRaw) && tzRaw !== user.timezone && user.timezone === "UTC") {
    await db.update(users).set({ timezone: tzRaw }).where(eq(users.id, user.id));
  }
  await createSession(user.id);
  redirect(user.onboardedAt ? "/today" : "/onboarding");
}

export async function logoutAction(): Promise<void> {
  await destroySession();
  redirect("/login");
}
