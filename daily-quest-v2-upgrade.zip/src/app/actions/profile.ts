"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { completions, dailyActivity, journalEntries, meals, moodEntries, quests, streakEvents, users } from "@/db/schema";
import { destroySession, newId, requireUser } from "@/lib/auth";
import { isValidTimezone } from "@/lib/dates";
import { CATEGORIES, DEFAULT_QUESTS, isCategory, type Category } from "@/lib/game";
import { generateQuests, suggestQuest, type GeneratedQuest, type Lang, type QuestSet } from "@/lib/ai";

// ---------- onboarding ----------
export async function generateQuestsAction(answers: Record<string, string>, locale: string): Promise<{ quests: QuestSet; ai: boolean }> {
  const user = await requireUser();
  const clean: Record<string, string> = {};
  for (const c of CATEGORIES) clean[c] = String(answers[c] ?? "").trim().slice(0, 300);
  const lang: Lang = locale === "ru" ? "ru" : "en";
  await db.update(users).set({ onboardingAnswers: clean, locale: lang, updatedAt: new Date() }).where(eq(users.id, user.id));
  return generateQuests(user.id, clean, lang);
}

export async function saveQuestSetAction(set: QuestSet): Promise<void> {
  const user = await requireUser();
  await db.transaction(async (tx) => {
    await tx.delete(quests).where(eq(quests.userId, user.id));
    const rows = [];
    for (const cat of CATEGORIES) {
      const list = Array.isArray(set[cat]) ? set[cat] : DEFAULT_QUESTS[cat];
      for (const tier of [1, 2, 3]) {
        const q = list.find((x) => x.tier === tier) ?? list[tier - 1] ?? DEFAULT_QUESTS[cat][tier - 1];
        rows.push({
          id: newId(),
          userId: user.id,
          category: cat,
          tier,
          emoji: (q.emoji || "✨").slice(0, 4),
          name: (q.name || DEFAULT_QUESTS[cat][tier - 1].name).trim().slice(0, 120),
        });
      }
    }
    await tx.insert(quests).values(rows);
    await tx.update(users).set({ onboardedAt: user.onboardedAt ?? new Date(), updatedAt: new Date() }).where(eq(users.id, user.id));
  });
  revalidatePath("/", "layout");
  redirect("/today");
}

// ---------- quests ----------
export async function updateQuestAction(category: string, tier: number, name: string, emoji: string): Promise<void> {
  const user = await requireUser();
  if (!isCategory(category) || ![1, 2, 3].includes(tier)) throw new Error("bad_input");
  const cleanName = name.trim().slice(0, 120);
  if (!cleanName) throw new Error("Quest name is required");
  await db
    .insert(quests)
    .values({ id: newId(), userId: user.id, category, tier, name: cleanName, emoji: emoji.trim().slice(0, 4) || "✨" })
    .onConflictDoUpdate({
      target: [quests.userId, quests.category, quests.tier],
      set: { name: cleanName, emoji: emoji.trim().slice(0, 4) || "✨", updatedAt: new Date() },
    });
  revalidatePath("/today");
  revalidatePath("/profile");
}

export async function suggestQuestAction(category: string, tier: number): Promise<GeneratedQuest> {
  const user = await requireUser();
  if (!isCategory(category) || ![1, 2, 3].includes(tier)) throw new Error("bad_input");
  const existing = await db.select({ name: quests.name }).from(quests).where(and(eq(quests.userId, user.id), eq(quests.category, category)));
  return suggestQuest(user.id, category as Category, tier, existing.map((e) => e.name), user.onboardingAnswers[category] ?? "", user.locale as Lang);
}

// ---------- profile ----------
export type ProfileState = { ok?: boolean; error?: string } | undefined;

export async function updateProfileAction(_prev: ProfileState, formData: FormData): Promise<ProfileState> {
  const user = await requireUser();
  const name = String(formData.get("name") ?? "").trim().slice(0, 80);
  const timezone = String(formData.get("timezone") ?? user.timezone);
  const locale = String(formData.get("locale") ?? user.locale) === "ru" ? "ru" : "en";
  const goal = Math.min(10_000, Math.max(800, Math.round(Number(formData.get("dailyCalorieGoal")) || user.dailyCalorieGoal)));
  if (!isValidTimezone(timezone)) return { error: "Unknown timezone." };
  await db.update(users).set({ name: name || null, timezone, locale, dailyCalorieGoal: goal, updatedAt: new Date() }).where(eq(users.id, user.id));
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function resetOnboardingAction(): Promise<void> {
  const user = await requireUser();
  await db.update(users).set({ onboardedAt: null, updatedAt: new Date() }).where(eq(users.id, user.id));
  revalidatePath("/", "layout");
  redirect("/onboarding");
}

export async function resetProgressAction(): Promise<void> {
  const user = await requireUser();
  await db.transaction(async (tx) => {
    await tx.delete(completions).where(eq(completions.userId, user.id));
    await tx.delete(streakEvents).where(eq(streakEvents.userId, user.id));
    await tx.delete(moodEntries).where(eq(moodEntries.userId, user.id));
    await tx.delete(journalEntries).where(eq(journalEntries.userId, user.id));
    await tx.delete(meals).where(eq(meals.userId, user.id));
    await tx.delete(dailyActivity).where(eq(dailyActivity.userId, user.id));
    await tx.update(users).set({ streakFreezes: 1, updatedAt: new Date() }).where(eq(users.id, user.id));
  });
  revalidatePath("/", "layout");
}

export async function deleteAccountAction(): Promise<void> {
  const user = await requireUser();
  await destroySession();
  await db.delete(users).where(eq(users.id, user.id));
  redirect("/login");
}
