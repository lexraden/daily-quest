"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { completions, dailyActivity, journalEntries, meals, moodEntries, quests } from "@/db/schema";
import { newId, requireUser } from "@/lib/auth";
import { todayIn } from "@/lib/dates";
import { isCategory, levelForXp } from "@/lib/game";
import { estimateMeal, type Lang } from "@/lib/ai";
import { getXpTotals, syncStreak } from "@/lib/data";

export interface ToggleResult {
  done: boolean;
  streak: number;
  levelUp: string | null;
  freezeAwarded: boolean;
}

/** Toggle a quest for today. Completions are keyed (user, day, category, tier). */
export async function toggleQuestAction(category: string, tier: number): Promise<ToggleResult> {
  const user = await requireUser();
  if (!isCategory(category) || ![1, 2, 3].includes(tier)) throw new Error("bad_input");
  const today = todayIn(user.timezone);

  const before = await getXpTotals(user.id);
  const existing = await db
    .select({ id: completions.id })
    .from(completions)
    .where(and(eq(completions.userId, user.id), eq(completions.day, today), eq(completions.category, category), eq(completions.tier, tier)))
    .limit(1);

  let done: boolean;
  if (existing[0]) {
    await db.delete(completions).where(eq(completions.id, existing[0].id));
    done = false;
  } else {
    const [quest] = await db
      .select()
      .from(quests)
      .where(and(eq(quests.userId, user.id), eq(quests.category, category), eq(quests.tier, tier)))
      .limit(1);
    await db
      .insert(completions)
      .values({ id: newId(), userId: user.id, day: today, category, tier, questName: quest?.name ?? `${category} ${tier}`, xp: tier })
      .onConflictDoNothing();
    done = true;
  }

  const freezesBefore = user.streakFreezes;
  const streak = await syncStreak(user, today);
  const after = await getXpTotals(user.id);
  const levelUp = done && levelForXp(after.totalXp).level > levelForXp(before.totalXp).level ? levelForXp(after.totalXp).name : null;

  revalidatePath("/today");
  revalidatePath("/history");
  revalidatePath("/stats");
  return { done, streak: streak.current, levelUp, freezeAwarded: streak.freezes > freezesBefore };
}

export async function setMoodAction(score: number, note: string): Promise<void> {
  const user = await requireUser();
  if (!Number.isInteger(score) || score < 1 || score > 5) throw new Error("bad_input");
  const today = todayIn(user.timezone);
  await db
    .insert(moodEntries)
    .values({ id: newId(), userId: user.id, day: today, score, note: note.trim().slice(0, 280) || null })
    .onConflictDoUpdate({ target: [moodEntries.userId, moodEntries.day], set: { score, note: note.trim().slice(0, 280) || null } });
  revalidatePath("/today");
}

export async function addJournalAction(content: string): Promise<void> {
  const user = await requireUser();
  const text = content.trim().slice(0, 4000);
  if (!text) return;
  await db.insert(journalEntries).values({ id: newId(), userId: user.id, day: todayIn(user.timezone), content: text });
  revalidatePath("/today");
  revalidatePath("/history");
}

export async function deleteJournalAction(id: string): Promise<void> {
  const user = await requireUser();
  await db.delete(journalEntries).where(and(eq(journalEntries.id, id), eq(journalEntries.userId, user.id)));
  revalidatePath("/today");
  revalidatePath("/history");
}

export interface MealInput {
  description: string;
  name?: string;
  calories?: number;
  protein?: number;
  fat?: number;
  carbs?: number;
}

/** Log a meal. If no calories given, estimate via OpenRouter (or heuristics). */
export async function addMealAction(input: MealInput): Promise<{ estimated: boolean; ai: boolean }> {
  const user = await requireUser();
  const description = input.description.trim().slice(0, 500);
  if (!description && !input.name) throw new Error("bad_input");
  const clamp = (v: unknown, max: number) => (typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(0, Math.round(v))) : null);

  let name = (input.name ?? "").trim().slice(0, 80);
  let calories = clamp(input.calories, 10_000);
  let protein = clamp(input.protein, 1000) ?? 0;
  let fat = clamp(input.fat, 1000) ?? 0;
  let carbs = clamp(input.carbs, 1000) ?? 0;
  let estimated = false;
  let ai = false;

  if (calories === null) {
    const est = await estimateMeal(user.id, description || name, user.locale as Lang);
    name = name || est.name;
    calories = est.calories;
    protein = est.protein;
    fat = est.fat;
    carbs = est.carbs;
    estimated = true;
    ai = est.ai;
  }

  await db.insert(meals).values({
    id: newId(),
    userId: user.id,
    day: todayIn(user.timezone),
    name: name || description.slice(0, 60) || "Meal",
    description: description || null,
    calories,
    protein,
    fat,
    carbs,
    aiEstimated: ai,
  });
  revalidatePath("/today");
  revalidatePath("/history");
  return { estimated, ai };
}

export async function deleteMealAction(id: string): Promise<void> {
  const user = await requireUser();
  await db.delete(meals).where(and(eq(meals.id, id), eq(meals.userId, user.id)));
  revalidatePath("/today");
  revalidatePath("/history");
}

export async function setCaloriesBurnedAction(value: number): Promise<void> {
  const user = await requireUser();
  const caloriesBurned = Math.min(20_000, Math.max(0, Math.round(Number(value) || 0)));
  const today = todayIn(user.timezone);
  await db
    .insert(dailyActivity)
    .values({ id: newId(), userId: user.id, day: today, caloriesBurned })
    .onConflictDoUpdate({ target: [dailyActivity.userId, dailyActivity.day], set: { caloriesBurned, updatedAt: new Date() } });
  revalidatePath("/today");
}
