import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { getCurrentUser, googleConfigured } from "@/lib/auth";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  google_not_configured: "Google sign-in is not configured on this server.",
  google_denied: "Google sign-in was cancelled.",
  google_state: "Sign-in session expired. Please try again.",
  google_unverified: "Verify your Google email address before signing in.",
  google_failed: "Google sign-in failed. Please try again.",
};

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const user = await getCurrentUser();
  if (user) redirect(user.onboardedAt ? "/today" : "/onboarding");
  const { error } = await searchParams;

  return (
    <main className="flex min-h-dvh items-center justify-center p-4">
      <AuthForm googleEnabled={googleConfigured()} initialError={error ? ERRORS[error] ?? "Sign-in failed." : null} />
    </main>
  );
}
