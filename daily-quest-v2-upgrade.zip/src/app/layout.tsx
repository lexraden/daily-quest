import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { TimezoneCookie } from "@/components/TimezoneCookie";

export const metadata: Metadata = {
  title: "DailyQ — Daily Quests",
  description: "Daily quests, streaks, mood, meals and journaling. Level up your life one day at a time.",
};

export const viewport: Viewport = {
  themeColor: "#0b0b14",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <TimezoneCookie />
        {children}
      </body>
    </html>
  );
}
