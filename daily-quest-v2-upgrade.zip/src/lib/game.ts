import { CATEGORIES, type Category } from "@/db/schema";
import { addDays, diffDays } from "./dates";

export { CATEGORIES };
export type { Category };

export const CATEGORY_META: Record<Category, { name: string; emoji: string; color: string; hint: string }> = {
  health: { name: "Health", emoji: "💪", color: "#00b894", hint: "movement, sleep, body" },
  mind: { name: "Mind", emoji: "🧠", color: "#a29bfe", hint: "learning, focus, calm" },
  work: { name: "Work", emoji: "💼", color: "#fdcb6e", hint: "craft, career, projects" },
  money: { name: "Money", emoji: "💰", color: "#00cec9", hint: "saving, earning, planning" },
  love: { name: "Love", emoji: "❤️", color: "#ff7675", hint: "partner, family, self-love" },
  friends: { name: "Friends", emoji: "🤝", color: "#fd79a8", hint: "connection, community" },
};

export const TIERS = [1, 2, 3] as const;
export const TIER_LABEL: Record<number, string> = { 1: "Easy", 2: "Medium", 3: "Hard" };

export const LEVELS = [
  { level: 1, threshold: 0, name: "Novice", icon: "🌱" },
  { level: 2, threshold: 10, name: "Apprentice", icon: "📚" },
  { level: 3, threshold: 25, name: "Adept", icon: "⚡" },
  { level: 4, threshold: 50, name: "Warrior", icon: "🔥" },
  { level: 5, threshold: 100, name: "Champion", icon: "💎" },
  { level: 6, threshold: 200, name: "Knight", icon: "⚔️" },
  { level: 7, threshold: 350, name: "Hero", icon: "🏆" },
  { level: 8, threshold: 550, name: "Master", icon: "👑" },
  { level: 9, threshold: 800, name: "Legend", icon: "🌟" },
  { level: 10, threshold: 1100, name: "Ascended", icon: "✨" },
] as const;

export const MAX_FREEZES = 3;
export const FREEZE_EVERY_DAYS = 7;
export const CATEGORY_LEVEL_STEP = 10; // XP per category level

export function levelForXp(xp: number) {
  let current: (typeof LEVELS)[number] = LEVELS[0];
  for (const l of LEVELS) if (xp >= l.threshold) current = l;
  const next = LEVELS.find((l) => l.threshold > current.threshold) ?? null;
  const span = next ? next.threshold - current.threshold : 1;
  const into = xp - current.threshold;
  return {
    ...current,
    next,
    progress: next ? Math.min(100, Math.round((into / span) * 100)) : 100,
    remaining: next ? next.threshold - xp : 0,
  };
}

export function categoryLevel(xp: number) {
  const level = Math.floor(xp / CATEGORY_LEVEL_STEP) + 1;
  const into = xp % CATEGORY_LEVEL_STEP;
  return { level, progress: Math.round((into / CATEGORY_LEVEL_STEP) * 100), remaining: CATEGORY_LEVEL_STEP - into };
}

export interface StreakInput {
  today: string;
  activeDays: Set<string>; // days with ≥1 completion
  frozenDays: Set<string>; // days already covered by a recorded freeze
  freezesAvailable: number;
}

export interface StreakResult {
  current: number;
  /** A missed day that should be covered by a freeze right now (not yet recorded). */
  freezeToApply: string | null;
  activeToday: boolean;
}

/**
 * Pure streak derivation. Walks backwards from today (or yesterday if today is
 * still open). A single missed day can be bridged by a freeze; two or more
 * consecutive missed days end the streak. Returns at most one new freeze to
 * record — callers persist it and decrement the counter.
 */
export function computeStreak(input: StreakInput): StreakResult {
  const { today, activeDays, frozenDays } = input;
  let freezes = input.freezesAvailable;
  let freezeToApply: string | null = null;
  const activeToday = activeDays.has(today);

  let cursor = activeToday ? today : addDays(today, -1);
  let count = 0;

  // Today not done yet: yesterday might be a gap we can bridge.
  for (let guard = 0; guard < 10_000; guard++) {
    if (activeDays.has(cursor)) {
      count++;
      cursor = addDays(cursor, -1);
      continue;
    }
    if (frozenDays.has(cursor)) {
      cursor = addDays(cursor, -1);
      continue;
    }
    // Gap. Can we bridge exactly one day, and is there history behind it?
    const before = addDays(cursor, -1);
    const hasHistoryBehind = activeDays.has(before) || frozenDays.has(before);
    if (hasHistoryBehind && freezes > 0 && !freezeToApply && cursor !== today) {
      freezes--;
      freezeToApply = cursor;
      cursor = before;
      continue;
    }
    break;
  }

  // A frozen day alone (with nothing before it) shouldn't count as a streak.
  return { current: count, freezeToApply, activeToday };
}

/** Longest run of consecutive active/frozen days, for stats. */
export function longestStreak(activeDays: Set<string>, frozenDays: Set<string>): number {
  const days = [...new Set([...activeDays, ...frozenDays])].sort();
  let best = 0;
  let run = 0;
  let prev: string | null = null;
  for (const d of days) {
    run = prev && diffDays(d, prev) === 1 ? run + 1 : 1;
    prev = d;
    if (activeDays.has(d)) best = Math.max(best, run);
  }
  return best;
}

export function isCategory(v: unknown): v is Category {
  return typeof v === "string" && (CATEGORIES as readonly string[]).includes(v);
}

export const DEFAULT_QUESTS: Record<Category, { tier: number; emoji: string; name: string }[]> = {
  health: [
    { tier: 1, emoji: "🚶", name: "Walk 20 minutes" },
    { tier: 2, emoji: "🏃", name: "30-minute workout or run" },
    { tier: 3, emoji: "🥗", name: "Workout + clean meals all day" },
  ],
  mind: [
    { tier: 1, emoji: "📖", name: "Read 10 pages" },
    { tier: 2, emoji: "🧘", name: "Meditate 15 minutes" },
    { tier: 3, emoji: "🎓", name: "One hour of deep learning" },
  ],
  work: [
    { tier: 1, emoji: "📝", name: "Plan the day's top 3 tasks" },
    { tier: 2, emoji: "🎯", name: "Finish the #1 priority task" },
    { tier: 3, emoji: "🚀", name: "2 hours of uninterrupted deep work" },
  ],
  money: [
    { tier: 1, emoji: "🧾", name: "Log today's spending" },
    { tier: 2, emoji: "🐖", name: "Move money into savings" },
    { tier: 3, emoji: "📈", name: "Learn or act on investing for 30 min" },
  ],
  love: [
    { tier: 1, emoji: "💬", name: "Send a caring message" },
    { tier: 2, emoji: "☕", name: "Quality time without phones" },
    { tier: 3, emoji: "🎁", name: "Plan a thoughtful surprise" },
  ],
  friends: [
    { tier: 1, emoji: "👋", name: "Check in on a friend" },
    { tier: 2, emoji: "📞", name: "Call a friend" },
    { tier: 3, emoji: "🍕", name: "Meet up in person" },
  ],
};
