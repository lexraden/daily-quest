import "server-only";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { aiUsage } from "@/db/schema";
import { CATEGORIES, CATEGORY_META, DEFAULT_QUESTS, type Category } from "./game";
import { newId } from "./auth";

/**
 * OpenRouter client. OpenAI-compatible chat completions over plain fetch — no
 * SDK, no vendor lock. Every feature has a deterministic fallback so the app
 * keeps working when OPENROUTER_API_KEY is missing or the provider is down.
 */
const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MODEL = () => process.env.OPENROUTER_MODEL || "openai/gpt-4o-mini";
const MONTHLY_LIMIT = () => Number(process.env.AI_MONTHLY_CALL_LIMIT || 500);

export type Lang = "en" | "ru";

export function aiConfigured(): boolean {
  return Boolean(process.env.OPENROUTER_API_KEY);
}

async function chargeQuota(userId: string): Promise<boolean> {
  const period = new Date().toISOString().slice(0, 7);
  const [row] = await db.select().from(aiUsage).where(and(eq(aiUsage.userId, userId), eq(aiUsage.period, period))).limit(1);
  if (row && row.calls >= MONTHLY_LIMIT()) return false;
  if (row) {
    await db.update(aiUsage).set({ calls: sql`${aiUsage.calls} + 1` }).where(eq(aiUsage.id, row.id));
  } else {
    await db.insert(aiUsage).values({ id: newId(), userId, period, calls: 1 }).onConflictDoNothing();
  }
  return true;
}

function extractJson(text: string): unknown {
  const trimmed = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
    throw new Error("ai_malformed");
  }
}

async function completeJson(userId: string, system: string, user: string, maxTokens = 1500): Promise<unknown | null> {
  if (!aiConfigured()) return null;
  if (!(await chargeQuota(userId))) return null;
  try {
    const res = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers: {
        authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        "content-type": "application/json",
        "HTTP-Referer": process.env.APP_URL || "https://dailyq.app",
        "X-Title": "DailyQ",
      },
      body: JSON.stringify({
        model: MODEL(),
        max_tokens: maxTokens,
        temperature: 0.7,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: `${system}\nRespond with a single JSON object and nothing else.` },
          { role: "user", content: user },
        ],
      }),
      signal: AbortSignal.timeout(45_000),
    });
    if (!res.ok) {
      console.warn("[ai] openrouter", res.status, await res.text().catch(() => ""));
      return null;
    }
    const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const content = data.choices?.[0]?.message?.content;
    if (!content) return null;
    return extractJson(content);
  } catch (err) {
    console.warn("[ai] failed", err);
    return null;
  }
}

// ---------- quest generation ----------
export type GeneratedQuest = { tier: number; emoji: string; name: string };
export type QuestSet = Record<Category, GeneratedQuest[]>;

function sanitizeQuestSet(raw: unknown): QuestSet {
  const src = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const out = {} as QuestSet;
  for (const cat of CATEGORIES) {
    const arr = Array.isArray(src[cat]) ? (src[cat] as unknown[]) : [];
    const cleaned = arr
      .map((q, i) => {
        const o = (q ?? {}) as Record<string, unknown>;
        const name = typeof o.name === "string" ? o.name.trim().slice(0, 120) : "";
        const emoji = typeof o.emoji === "string" && o.emoji.trim() ? o.emoji.trim().slice(0, 4) : "✨";
        const tier = typeof o.tier === "number" ? o.tier : typeof o.level === "number" ? o.level : i + 1;
        return { tier: Math.min(3, Math.max(1, Math.round(tier))), emoji, name };
      })
      .filter((q) => q.name.length > 0)
      .sort((a, b) => a.tier - b.tier);
    const byTier: GeneratedQuest[] = [];
    for (const tier of [1, 2, 3]) {
      const found = cleaned.find((q) => q.tier === tier && !byTier.includes(q)) ?? cleaned[tier - 1];
      byTier.push(found ? { ...found, tier } : DEFAULT_QUESTS[cat][tier - 1]);
    }
    out[cat] = byTier;
  }
  return out;
}

export async function generateQuests(userId: string, answers: Record<string, string>, lang: Lang): Promise<{ quests: QuestSet; ai: boolean }> {
  const answerLines = CATEGORIES.map((c) => `${c} (${CATEGORY_META[c].hint}): ${answers[c] || "(no answer)"}`).join("\n");
  const system =
    lang === "ru"
      ? "Ты эксперт по личному развитию. Создаёшь ЕЖЕДНЕВНЫЕ квесты (действия на каждый день, не долгосрочные цели). Отвечай на русском."
      : "You are a personal-growth coach. You create DAILY quests (repeatable every day, not long-term goals). Answer in English.";
  const user = `User's goals per life area:\n${answerLines}\n\nFor EACH of the six categories (health, mind, work, money, love, friends) return exactly 3 daily quests sorted by difficulty: tier 1 (easy, ~10 min), tier 2 (medium), tier 3 (ambitious but doable daily). Short imperative names (max 8 words) with one fitting emoji.\nJSON shape: {"health":[{"tier":1,"emoji":"🚶","name":"..."},{"tier":2,...},{"tier":3,...}],"mind":[...],"work":[...],"money":[...],"love":[...],"friends":[...]}`;
  const raw = await completeJson(userId, system, user, 2500);
  if (!raw) return { quests: sanitizeQuestSet(DEFAULT_QUESTS), ai: false };
  return { quests: sanitizeQuestSet(raw), ai: true };
}

export async function suggestQuest(
  userId: string,
  category: Category,
  tier: number,
  existing: string[],
  goal: string,
  lang: Lang,
): Promise<GeneratedQuest> {
  const system = lang === "ru" ? "Ты коуч по привычкам. Отвечай на русском." : "You are a habit coach. Answer in English.";
  const user = `Suggest ONE new daily quest for the "${category}" area (${CATEGORY_META[category].hint}), difficulty tier ${tier} of 3. User's goal: ${goal || "not specified"}. Avoid these existing quests: ${existing.join("; ") || "none"}. JSON: {"emoji":"…","name":"… (max 8 words)"}`;
  const raw = (await completeJson(userId, system, user, 200)) as Record<string, unknown> | null;
  if (raw && typeof raw.name === "string" && raw.name.trim()) {
    return { tier, emoji: typeof raw.emoji === "string" && raw.emoji ? raw.emoji.slice(0, 4) : "✨", name: raw.name.trim().slice(0, 120) };
  }
  const pool = DEFAULT_QUESTS[category].filter((q) => !existing.includes(q.name));
  return pool[0] ? { ...pool[0], tier } : { tier, emoji: "✨", name: `${CATEGORY_META[category].name} quest (tier ${tier})` };
}

// ---------- meal estimation ----------
export interface MealEstimate {
  name: string;
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
  ai: boolean;
}

const KEYWORDS: { re: RegExp; kcal: number; p: number; f: number; c: number }[] = [
  { re: /salad|салат/i, kcal: 250, p: 8, f: 15, c: 20 },
  { re: /chicken|курин|куриц/i, kcal: 350, p: 40, f: 10, c: 5 },
  { re: /rice|рис/i, kcal: 250, p: 5, f: 1, c: 55 },
  { re: /pasta|макарон|паста/i, kcal: 450, p: 15, f: 10, c: 75 },
  { re: /pizza|пицц/i, kcal: 600, p: 25, f: 25, c: 70 },
  { re: /burger|бургер/i, kcal: 650, p: 30, f: 35, c: 50 },
  { re: /egg|яйц|яичн/i, kcal: 180, p: 13, f: 13, c: 1 },
  { re: /oat|овсян|каша/i, kcal: 300, p: 10, f: 6, c: 55 },
  { re: /yogurt|йогурт|творог/i, kcal: 150, p: 12, f: 4, c: 15 },
  { re: /fish|salmon|рыб|лосос/i, kcal: 320, p: 35, f: 18, c: 0 },
  { re: /soup|суп|борщ/i, kcal: 220, p: 10, f: 8, c: 25 },
  { re: /sandwich|бутерброд|сэндвич/i, kcal: 400, p: 18, f: 15, c: 45 },
  { re: /fruit|apple|banana|фрукт|яблок|банан/i, kcal: 100, p: 1, f: 0, c: 25 },
  { re: /coffee|latte|кофе|латте/i, kcal: 120, p: 4, f: 5, c: 12 },
  { re: /steak|beef|говяд|стейк/i, kcal: 500, p: 45, f: 30, c: 0 },
  { re: /cake|dessert|торт|десерт|шоколад|chocolate/i, kcal: 400, p: 5, f: 20, c: 50 },
];

function heuristicMeal(description: string): MealEstimate {
  let kcal = 0, p = 0, f = 0, c = 0;
  for (const k of KEYWORDS) if (k.re.test(description)) { kcal += k.kcal; p += k.p; f += k.f; c += k.c; }
  if (kcal === 0) { kcal = 400; p = 20; f = 15; c = 45; }
  const name = description.trim().split(/[.,\n]/)[0].slice(0, 60) || "Meal";
  return { name: name.charAt(0).toUpperCase() + name.slice(1), calories: kcal, protein: p, fat: f, carbs: c, ai: false };
}

export async function estimateMeal(userId: string, description: string, lang: Lang): Promise<MealEstimate> {
  const system = lang === "ru" ? "Ты нутрициолог. Оцениваешь КБЖУ блюда по описанию. Название — на русском." : "You are a nutritionist estimating calories and macros from a meal description.";
  const user = `Meal: "${description}". Estimate a realistic single serving. JSON: {"name":"short dish name","calories":number,"protein":grams,"fat":grams,"carbs":grams}`;
  const raw = (await completeJson(userId, system, user, 200)) as Record<string, unknown> | null;
  const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? Math.max(0, Math.round(v)) : null);
  if (raw && num(raw.calories) !== null) {
    return {
      name: typeof raw.name === "string" && raw.name.trim() ? raw.name.trim().slice(0, 80) : heuristicMeal(description).name,
      calories: num(raw.calories)!,
      protein: num(raw.protein) ?? 0,
      fat: num(raw.fat) ?? 0,
      carbs: num(raw.carbs) ?? 0,
      ai: true,
    };
  }
  return heuristicMeal(description);
}

// ---------- daily motivation ----------
export async function dailyMotivation(userId: string, ctx: { name: string | null; streak: number; level: string; doneToday: number; lang: Lang }): Promise<string> {
  const fallback = [
    `Small steps, ${ctx.name ?? "hero"}. One quest at a time.`,
    ctx.streak > 0 ? `${ctx.streak}-day streak. Protect it today.` : "Today is a great day to start a streak.",
    ctx.doneToday > 0 ? "Momentum is on your side — keep going." : "Pick the easiest quest and just begin.",
  ];
  const line = fallback[new Date().getUTCDate() % fallback.length];
  if (!aiConfigured()) return line;
  const raw = (await completeJson(
    userId,
    ctx.lang === "ru" ? "Ты тёплый, лаконичный мотивационный коуч. Отвечай на русском." : "You are a warm, concise motivational coach.",
    `User ${ctx.name ?? "hero"} is level "${ctx.level}", streak ${ctx.streak} days, finished ${ctx.doneToday} quests today. Write ONE encouraging sentence (max 18 words), no emojis. JSON: {"message":"..."}`,
    80,
  )) as Record<string, unknown> | null;
  return raw && typeof raw.message === "string" && raw.message.trim() ? raw.message.trim() : line;
}
