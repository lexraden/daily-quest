import "server-only";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { randomBytes, scryptSync, timingSafeEqual, createHash, randomUUID } from "node:crypto";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, type User } from "@/db/schema";
import { isValidTimezone } from "./dates";

export const SESSION_COOKIE = "dq_session";
export const TZ_COOKIE = "dq_tz";
const SESSION_DAYS = 30;

export const newId = () => randomUUID();

// ---------- passwords ----------
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string | null): boolean {
  if (!stored) return false;
  const [, salt, hash] = stored.split("$");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

// ---------- sessions ----------
const hashToken = (t: string) => createHash("sha256").update(t).digest("hex");

export async function createSession(userId: string): Promise<void> {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000);
  await db.insert(sessions).values({ id: newId(), userId, tokenHash: hashToken(token), expiresAt });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, hashToken(token)));
  jar.delete(SESSION_COOKIE);
}

export async function getCurrentUser(): Promise<User | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return rows[0]?.user ?? null;
}

/** Redirects to /login when there is no session (works in pages and Server Actions). */
export async function requireUser(): Promise<User> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/** Best-effort browser timezone, captured by a cookie set client-side. */
export async function browserTimezone(fallback = "UTC"): Promise<string> {
  const jar = await cookies();
  const tz = jar.get(TZ_COOKIE)?.value;
  return tz && isValidTimezone(tz) ? tz : fallback;
}

// ---------- Google OAuth (authorization-code flow) ----------
export function googleConfigured(): boolean {
  return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}

export async function appBaseUrl(): Promise<string> {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, "");
  if (process.env.NEXT_PUBLIC_APP_URL) return process.env.NEXT_PUBLIC_APP_URL.replace(/\/$/, "");
  if (process.env.RAILWAY_PUBLIC_DOMAIN) return `https://${process.env.RAILWAY_PUBLIC_DOMAIN}`;
  const h = await headers();
  const proto = h.get("x-forwarded-proto") ?? "http";
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  return `${proto}://${host}`;
}

export interface GoogleProfile {
  sub: string;
  email: string;
  name?: string;
  picture?: string;
  email_verified?: boolean;
}

export async function exchangeGoogleCode(code: string, redirectUri: string): Promise<GoogleProfile> {
  const body = new URLSearchParams({
    code,
    client_id: process.env.GOOGLE_CLIENT_ID!,
    client_secret: process.env.GOOGLE_CLIENT_SECRET!,
    redirect_uri: redirectUri,
    grant_type: "authorization_code",
  });
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!tokenRes.ok) throw new Error(`google_token_${tokenRes.status}`);
  const tokens = (await tokenRes.json()) as { access_token?: string };
  if (!tokens.access_token) throw new Error("google_no_access_token");

  const infoRes = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
    headers: { authorization: `Bearer ${tokens.access_token}` },
  });
  if (!infoRes.ok) throw new Error(`google_userinfo_${infoRes.status}`);
  const profile = (await infoRes.json()) as GoogleProfile;
  if (!profile.sub || !profile.email) throw new Error("google_incomplete_profile");
  return profile;
}

/** Find-or-create by Google account id; link by email if the account already exists. */
export async function upsertGoogleUser(profile: GoogleProfile, timezone: string): Promise<User> {
  const email = profile.email.toLowerCase();
  const bySub = await db.select().from(users).where(eq(users.googleSub, profile.sub)).limit(1);
  if (bySub[0]) {
    const [u] = await db
      .update(users)
      .set({ email, avatarUrl: profile.picture ?? bySub[0].avatarUrl, updatedAt: new Date() })
      .where(eq(users.id, bySub[0].id))
      .returning();
    return u;
  }
  const byEmail = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (byEmail[0]) {
    const [u] = await db
      .update(users)
      .set({
        googleSub: profile.sub,
        name: byEmail[0].name ?? profile.name ?? null,
        avatarUrl: byEmail[0].avatarUrl ?? profile.picture ?? null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, byEmail[0].id))
      .returning();
    return u;
  }
  const [u] = await db
    .insert(users)
    .values({
      id: newId(),
      email,
      googleSub: profile.sub,
      name: profile.name ?? null,
      avatarUrl: profile.picture ?? null,
      timezone,
    })
    .returning();
  return u;
}
