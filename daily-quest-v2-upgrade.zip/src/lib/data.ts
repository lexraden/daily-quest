import "server-only";
import { and, asc, desc, eq, gte, lte, sql } from "drizzle-orm";
import type { AnyPgColumn } from "drizzle-orm/pg-core";
import { db } from "@/db";
import {
  completions,
  dailyActivity,
  journalEntries,
  meals,
  moodEntries,
  quests,
  streakEvents,
  users,
  type User,
} from "@/db/schema";
import { addDays, todayIn } from "./dates";
import {
  CATEGORIES,
  categoryLevel,
  computeStreak,
  FREEZE_EVERY_DAYS,
  levelForXp,
  longestStreak,
  MAX_FREEZES,
  type Category,
} from "./game";
import { newId } from "./auth";

export interface StreakSummary {
  current: number;
  longest: number;
  freezes: number;
  activeToday: boolean;
  freezeAppliedFor: string | null;
}

/**
 * Derive streak from history; if a single-day gap should be bridged, record the
 * freeze and decrement the counter. Called from the dashboard and after each
 * completion, so state is always consistent with the completions table.
 */
export async function syncStreak(user: User, today = todayIn(user.timezone)): Promise<StreakSummary> {
  const [days, events] = await Promise.all([
    db.selectDistinct({ day: completions.day }).from(completions).where(eq(completions.userId, user.id)),
    db.select().from(streakEvents).where(eq(streakEvents.userId, user.id)),
  ]);
  const activeDays = new Set(days.map((d) => d.day));
  const frozenDays = new Set(events.filter((e) => e.kind === "freeze_used").map((e) => e.day));
  let freezes = user.streakFreezes;

  const result = computeStreak({ today, activeDays, frozenDays, freezesAvailable: freezes });
  let freezeAppliedFor: string | null = null;

  if (result.freezeToApply) {
    const inserted = await db
      .insert(streakEvents)
      .values({ id: newId(), userId: user.id, day: result.freezeToApply, kind: "freeze_used" })
      .onConflictDoNothing()
      .returning();
    if (inserted.length) {
      freezes = Math.max(0, freezes - 1);
      await db.update(users).set({ streakFreezes: freezes }).where(eq(users.id, user.id));
      frozenDays.add(result.freezeToApply);
      freezeAppliedFor = result.freezeToApply;
    }
  }

  // Award a freeze at each 7-day milestone (once per day), capped.
  if (result.activeToday && result.current > 0 && result.current % FREEZE_EVERY_DAYS === 0 && freezes < MAX_FREEZES) {
    const awarded = await db
      .insert(streakEvents)
      .values({ id: newId(), userId: user.id, day: today, kind: "freeze_awarded" })
      .onConflictDoNothing()
      .returning();
    if (awarded.length) {
      freezes = Math.min(MAX_FREEZES, freezes + 1);
      await db.update(users).set({ streakFreezes: freezes }).where(eq(users.id, user.id));
    }
  }

  return {
    current: result.current,
    longest: Math.max(result.current, longestStreak(activeDays, frozenDays)),
    freezes,
    activeToday: result.activeToday,
    freezeAppliedFor,
  };
}

export async function getQuests(userId: string) {
  return db.select().from(quests).where(eq(quests.userId, userId)).orderBy(asc(quests.category), asc(quests.tier));
}

export async function getXpTotals(userId: string) {
  const rows = await db
    .select({ category: completions.category, xp: sql<number>`coalesce(sum(${completions.xp}), 0)::int`, count: sql<number>`count(*)::int` })
    .from(completions)
    .where(eq(completions.userId, userId))
    .groupBy(completions.category);
  const byCategory = Object.fromEntries(CATEGORIES.map((c) => [c, { xp: 0, count: 0 }])) as Record<Category, { xp: number; count: number }>;
  let totalXp = 0;
  let totalCount = 0;
  for (const r of rows) {
    if (r.category in byCategory) byCategory[r.category as Category] = { xp: r.xp, count: r.count };
    totalXp += r.xp;
    totalCount += r.count;
  }
  return { byCategory, totalXp, totalCount };
}

export async function getDashboard(user: User) {
  const today = todayIn(user.timezone);
  const [streak, questRows, totals, todayCompletions, mood, todayMeals, activity, journal] = await Promise.all([
    syncStreak(user, today),
    getQuests(user.id),
    getXpTotals(user.id),
    db.select().from(completions).where(and(eq(completions.userId, user.id), eq(completions.day, today))),
    db.select().from(moodEntries).where(and(eq(moodEntries.userId, user.id), eq(moodEntries.day, today))).limit(1),
    db.select().from(meals).where(and(eq(meals.userId, user.id), eq(meals.day, today))).orderBy(desc(meals.createdAt)),
    db.select().from(dailyActivity).where(and(eq(dailyActivity.userId, user.id), eq(dailyActivity.day, today))).limit(1),
    db.select().from(journalEntries).where(and(eq(journalEntries.userId, user.id), eq(journalEntries.day, today))).orderBy(desc(journalEntries.createdAt)),
  ]);

  const doneKeys = new Set(todayCompletions.map((c) => `${c.category}:${c.tier}`));
  const categories = CATEGORIES.map((cat) => ({
    category: cat,
    quests: questRows
      .filter((q) => q.category === cat)
      .map((q) => ({ ...q, done: doneKeys.has(`${cat}:${q.tier}`) })),
    level: categoryLevel(totals.byCategory[cat].xp),
    xp: totals.byCategory[cat].xp,
  }));

  return {
    today,
    streak,
    level: levelForXp(totals.totalXp),
    totalXp: totals.totalXp,
    totalCompleted: totals.totalCount,
    xpToday: todayCompletions.reduce((s, c) => s + c.xp, 0),
    doneToday: todayCompletions.length,
    categories,
    mood: mood[0] ?? null,
    meals: todayMeals,
    caloriesBurned: activity[0]?.caloriesBurned ?? 0,
    journal,
  };
}

export async function getMonthData(user: User, month: string) {
  const from = `${month}-01`;
  const to = `${month}-31`;
  const where = (col: AnyPgColumn, uid: AnyPgColumn) => and(eq(uid, user.id), gte(col, from), lte(col, to));
  const [comp, moods, mealRows, journal, events] = await Promise.all([
    db.select().from(completions).where(where(completions.day, completions.userId)).orderBy(asc(completions.completedAt)),
    db.select().from(moodEntries).where(where(moodEntries.day, moodEntries.userId)),
    db.select().from(meals).where(where(meals.day, meals.userId)).orderBy(asc(meals.createdAt)),
    db.select().from(journalEntries).where(where(journalEntries.day, journalEntries.userId)).orderBy(asc(journalEntries.createdAt)),
    db.select().from(streakEvents).where(where(streakEvents.day, streakEvents.userId)),
  ]);
  return { completions: comp, moods, meals: mealRows, journal, events };
}

export async function getStats(user: User) {
  const today = todayIn(user.timezone);
  const start = addDays(today, -29);
  const [recent, totals, streak, moods, allDays] = await Promise.all([
    db.select().from(completions).where(and(eq(completions.userId, user.id), gte(completions.day, start))),
    getXpTotals(user.id),
    syncStreak(user, today),
    db.select().from(moodEntries).where(and(eq(moodEntries.userId, user.id), gte(moodEntries.day, start))).orderBy(asc(moodEntries.day)),
    db.selectDistinct({ day: completions.day }).from(completions).where(eq(completions.userId, user.id)),
  ]);
  const last30 = Array.from({ length: 30 }, (_, i) => addDays(start, i)).map((day) => {
    const rows = recent.filter((c) => c.day === day);
    return { day, count: rows.length, xp: rows.reduce((s, c) => s + c.xp, 0) };
  });
  const last7 = last30.slice(-7);
  return {
    today,
    totals,
    streak,
    level: levelForXp(totals.totalXp),
    last30,
    last7,
    moods,
    activeDaysTotal: allDays.length,
    avgPerActiveDay: allDays.length ? Math.round((totals.totalCount / allDays.length) * 10) / 10 : 0,
    bestDay: last30.reduce((best, d) => (d.xp > best.xp ? d : best), last30[0]),
  };
}
