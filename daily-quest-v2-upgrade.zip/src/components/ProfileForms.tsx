"use client";

import { useActionState, useState, useTransition } from "react";
import { logoutAction } from "@/app/actions/auth";
import { deleteAccountAction, resetOnboardingAction, resetProgressAction, suggestQuestAction, updateProfileAction, updateQuestAction, type ProfileState } from "@/app/actions/profile";
import { CATEGORIES, CATEGORY_META, TIER_LABEL, type Category } from "@/lib/game";
import { CelebrateProvider, useCelebrate } from "./Celebrate";

const TIMEZONES = (() => {
  try {
    return (Intl as unknown as { supportedValuesOf?: (k: string) => string[] }).supportedValuesOf?.("timeZone") ?? [];
  } catch {
    return [];
  }
})();

export function ProfileForms(props: {
  user: { name: string | null; email: string; timezone: string; locale: string; dailyCalorieGoal: number; hasPassword: boolean; hasGoogle: boolean };
  quests: { category: string; tier: number; emoji: string; name: string }[];
  aiEnabled: boolean;
}) {
  return (
    <CelebrateProvider>
      <SettingsForm user={props.user} />
      <QuestEditor quests={props.quests} aiEnabled={props.aiEnabled} />
      <DangerZone />
    </CelebrateProvider>
  );
}

function SettingsForm({ user }: { user: { name: string | null; email: string; timezone: string; locale: string; dailyCalorieGoal: number; hasPassword: boolean; hasGoogle: boolean } }) {
  const [state, action, pending] = useActionState<ProfileState, FormData>(updateProfileAction, undefined);
  const tzList = TIMEZONES.includes(user.timezone) || TIMEZONES.length === 0 ? TIMEZONES : [user.timezone, ...TIMEZONES];
  return (
    <form action={action} className="card space-y-3 p-4">
      <h2 className="font-semibold">Settings</h2>
      <div className="text-xs text-muted">
        {user.email} · signed in with {[user.hasGoogle && "Google", user.hasPassword && "password"].filter(Boolean).join(" & ")}
      </div>
      <div>
        <label className="label" htmlFor="name">Name</label>
        <input id="name" name="name" className="input" defaultValue={user.name ?? ""} maxLength={80} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label" htmlFor="timezone">Timezone</label>
          {tzList.length ? (
            <select id="timezone" name="timezone" className="input" defaultValue={user.timezone}>
              {tzList.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
            </select>
          ) : (
            <input id="timezone" name="timezone" className="input" defaultValue={user.timezone} />
          )}
        </div>
        <div>
          <label className="label" htmlFor="locale">AI language</label>
          <select id="locale" name="locale" className="input" defaultValue={user.locale}>
            <option value="en">English</option>
            <option value="ru">Русский</option>
          </select>
        </div>
      </div>
      <div>
        <label className="label" htmlFor="dailyCalorieGoal">Daily calorie goal</label>
        <input id="dailyCalorieGoal" name="dailyCalorieGoal" type="number" min={800} max={10000} className="input" defaultValue={user.dailyCalorieGoal} />
      </div>
      {state?.error && <p className="text-sm text-red-300">{state.error}</p>}
      {state?.ok && <p className="text-sm text-accent-2">Saved.</p>}
      <button className="btn-primary w-full" disabled={pending}>{pending ? "Saving…" : "Save settings"}</button>
    </form>
  );
}

function QuestEditor({ quests, aiEnabled }: { quests: { category: string; tier: number; emoji: string; name: string }[]; aiEnabled: boolean }) {
  const [editing, setEditing] = useState<{ category: Category; tier: number; emoji: string; name: string } | null>(null);
  const [pending, start] = useTransition();
  const { toast } = useCelebrate();

  const save = () =>
    start(async () => {
      if (!editing) return;
      try {
        await updateQuestAction(editing.category, editing.tier, editing.name, editing.emoji);
        toast("Quest updated", "success");
        setEditing(null);
      } catch (e) {
        toast(e instanceof Error ? e.message : "Could not save");
      }
    });

  const suggest = () =>
    start(async () => {
      if (!editing) return;
      try {
        const s = await suggestQuestAction(editing.category, editing.tier);
        setEditing({ ...editing, emoji: s.emoji, name: s.name });
      } catch {
        toast("Could not get a suggestion");
      }
    });

  return (
    <section className="card p-4">
      <h2 className="font-semibold">Your quests</h2>
      <p className="mt-1 text-xs text-muted">Tap a quest to edit it{aiEnabled ? " or ask AI for a fresh idea" : ""}.</p>
      <div className="mt-3 space-y-3">
        {CATEGORIES.map((c) => (
          <div key={c}>
            <div className="mb-1 text-xs font-semibold" style={{ color: CATEGORY_META[c].color }}>{CATEGORY_META[c].emoji} {CATEGORY_META[c].name}</div>
            <div className="space-y-1">
              {[1, 2, 3].map((tier) => {
                const q = quests.find((x) => x.category === c && x.tier === tier) ?? { emoji: "✨", name: "(not set)" };
                const isEditing = editing?.category === c && editing.tier === tier;
                return (
                  <div key={tier}>
                    {isEditing ? (
                      <div className="rounded-xl border border-accent/50 bg-panel-2 p-2">
                        <div className="flex gap-2">
                          <input className="input w-14 text-center" value={editing.emoji} maxLength={4} onChange={(e) => setEditing({ ...editing, emoji: e.target.value })} />
                          <input className="input" value={editing.name} maxLength={120} onChange={(e) => setEditing({ ...editing, name: e.target.value })} autoFocus />
                        </div>
                        <div className="mt-2 flex gap-2">
                          <button className="btn-ghost flex-1 py-1.5" onClick={() => setEditing(null)} disabled={pending}>Cancel</button>
                          {aiEnabled && <button className="btn-ghost flex-1 py-1.5" onClick={suggest} disabled={pending}>✨ Suggest</button>}
                          <button className="btn-primary flex-1 py-1.5" onClick={save} disabled={pending || !editing.name.trim()}>Save</button>
                        </div>
                      </div>
                    ) : (
                      <button className="flex w-full items-center gap-2 rounded-xl bg-panel-2 px-3 py-2 text-left text-sm hover:bg-[#242436]" onClick={() => setEditing({ category: c, tier, emoji: q.emoji, name: q.name === "(not set)" ? "" : q.name })}>
                        <span className="w-12 text-[10px] text-muted">{TIER_LABEL[tier]}</span>
                        <span>{q.emoji}</span>
                        <span className="flex-1">{q.name}</span>
                        <span className="text-xs text-muted">✎</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function DangerZone() {
  const [pending, start] = useTransition();
  const confirmRun = (msg: string, fn: () => Promise<void>) => {
    if (typeof window !== "undefined" && window.confirm(msg)) start(fn);
  };
  return (
    <section className="card space-y-2 p-4">
      <h2 className="font-semibold">Account</h2>
      <a href="/api/export" className="btn-ghost w-full">⬇️ Export my data (JSON)</a>
      <button className="btn-ghost w-full" disabled={pending} onClick={() => confirmRun("Re-run onboarding? Your quests will be regenerated; progress is kept.", resetOnboardingAction)}>🔄 Redo onboarding / regenerate quests</button>
      <button className="btn-danger w-full" disabled={pending} onClick={() => confirmRun("Reset ALL progress (completions, streaks, moods, meals, journal)? This cannot be undone.", resetProgressAction)}>♻️ Reset progress</button>
      <button className="btn-danger w-full" disabled={pending} onClick={() => confirmRun("Delete your account and all data permanently?", deleteAccountAction)}>🗑️ Delete account</button>
      <form action={logoutAction}><button className="btn-ghost w-full">Sign out</button></form>
    </section>
  );
}
