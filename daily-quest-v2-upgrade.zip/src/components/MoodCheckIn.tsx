"use client";

import { useState, useTransition } from "react";
import { setMoodAction } from "@/app/actions/today";
import { useCelebrate } from "./Celebrate";

export const MOODS = [
  { score: 1, emoji: "😞", label: "Rough" },
  { score: 2, emoji: "😕", label: "Meh" },
  { score: 3, emoji: "😐", label: "Okay" },
  { score: 4, emoji: "🙂", label: "Good" },
  { score: 5, emoji: "🤩", label: "Great" },
];

export function MoodCheckIn({ initial }: { initial: { score: number; note: string | null } | null }) {
  const [score, setScore] = useState<number | null>(initial?.score ?? null);
  const [note, setNote] = useState(initial?.note ?? "");
  const [open, setOpen] = useState(!initial);
  const [pending, start] = useTransition();
  const { toast } = useCelebrate();

  const save = (s: number) =>
    start(async () => {
      setScore(s);
      try {
        await setMoodAction(s, note);
        setOpen(false);
        toast("Mood saved");
      } catch {
        toast("Could not save mood");
      }
    });

  const current = MOODS.find((m) => m.score === score);

  return (
    <section className="card p-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">How are you today?</h3>
        {current && !open && (
          <button className="text-sm text-muted hover:text-white" onClick={() => setOpen(true)}>
            {current.emoji} {current.label} · edit
          </button>
        )}
      </div>
      {open && (
        <div className="mt-3 space-y-3">
          <div className="grid grid-cols-5 gap-2">
            {MOODS.map((m) => (
              <button
                key={m.score}
                type="button"
                disabled={pending}
                onClick={() => save(m.score)}
                className={`flex flex-col items-center gap-1 rounded-xl border py-2 text-xs transition ${score === m.score ? "border-accent bg-accent/20" : "border-line bg-panel-2 hover:border-accent/50"}`}
              >
                <span className="text-2xl">{m.emoji}</span>
                <span className="text-muted">{m.label}</span>
              </button>
            ))}
          </div>
          <input className="input" placeholder="Optional note (why?)" value={note} maxLength={280} onChange={(e) => setNote(e.target.value)} onBlur={() => score && save(score)} />
        </div>
      )}
    </section>
  );
}
