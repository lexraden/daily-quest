"use client";

import { useState, useTransition } from "react";
import { addMealAction, deleteMealAction, setCaloriesBurnedAction } from "@/app/actions/today";
import { useCelebrate } from "./Celebrate";

export interface MealView {
  id: string;
  name: string;
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
  aiEstimated: boolean;
}

export function FuelPanel({ meals, caloriesBurned, goal, aiEnabled }: { meals: MealView[]; caloriesBurned: number; goal: number; aiEnabled: boolean }) {
  const [desc, setDesc] = useState("");
  const [manual, setManual] = useState(false);
  const [kcal, setKcal] = useState("");
  const [macros, setMacros] = useState({ protein: "", fat: "", carbs: "" });
  const [burned, setBurned] = useState(String(caloriesBurned || ""));
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const { toast } = useCelebrate();

  const eaten = meals.reduce((s, m) => s + m.calories, 0);
  const totals = meals.reduce((s, m) => ({ p: s.p + m.protein, f: s.f + m.fat, c: s.c + m.carbs }), { p: 0, f: 0, c: 0 });
  const net = eaten - caloriesBurned;
  const pct = Math.min(100, Math.round((eaten / goal) * 100));

  const submit = () =>
    start(async () => {
      if (!desc.trim()) return;
      try {
        const res = await addMealAction({
          description: desc,
          calories: manual && kcal ? Number(kcal) : undefined,
          protein: manual ? Number(macros.protein) || 0 : undefined,
          fat: manual ? Number(macros.fat) || 0 : undefined,
          carbs: manual ? Number(macros.carbs) || 0 : undefined,
        });
        setDesc("");
        setKcal("");
        setMacros({ protein: "", fat: "", carbs: "" });
        toast(res.estimated ? (res.ai ? "Meal logged · estimated by AI" : "Meal logged · rough estimate") : "Meal logged", "success");
      } catch {
        toast("Could not log meal");
      }
    });

  const saveBurned = () =>
    start(async () => {
      try {
        await setCaloriesBurnedAction(Number(burned) || 0);
        toast("Activity saved");
      } catch {
        toast("Could not save");
      }
    });

  return (
    <section className="card p-4">
      <header className="flex items-center justify-between">
        <h3 className="font-semibold">Fuel</h3>
        <button className="text-sm text-muted hover:text-white" onClick={() => setOpen((o) => !o)}>{open ? "Hide" : "Details"}</button>
      </header>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        <Stat label="Eaten" value={eaten} unit="kcal" />
        <Stat label="Burned" value={caloriesBurned} unit="kcal" />
        <Stat label="Net" value={net} unit="kcal" accent={net > goal ? "#ff7675" : "#00b894"} />
      </div>
      <div className="mt-3">
        <div className="mb-1 flex justify-between text-[11px] text-muted"><span>Goal {goal} kcal</span><span>{pct}%</span></div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-panel-2">
          <div className="h-full rounded-full bg-gradient-to-r from-accent-2 to-accent transition-all" style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-1 text-[11px] text-muted">P {Math.round(totals.p)}g · F {Math.round(totals.f)}g · C {Math.round(totals.c)}g</div>
      </div>

      <div className="mt-4 space-y-2">
        <textarea className="input min-h-16" placeholder={aiEnabled ? "What did you eat? e.g. 'chicken rice bowl with avocado'" : "What did you eat?"} value={desc} maxLength={500} onChange={(e) => setDesc(e.target.value)} />
        <label className="flex items-center gap-2 text-xs text-muted">
          <input type="checkbox" checked={manual} onChange={(e) => setManual(e.target.checked)} /> Enter calories manually
        </label>
        {manual && (
          <div className="grid grid-cols-4 gap-2">
            <input className="input" placeholder="kcal" inputMode="numeric" value={kcal} onChange={(e) => setKcal(e.target.value)} />
            <input className="input" placeholder="P g" inputMode="numeric" value={macros.protein} onChange={(e) => setMacros({ ...macros, protein: e.target.value })} />
            <input className="input" placeholder="F g" inputMode="numeric" value={macros.fat} onChange={(e) => setMacros({ ...macros, fat: e.target.value })} />
            <input className="input" placeholder="C g" inputMode="numeric" value={macros.carbs} onChange={(e) => setMacros({ ...macros, carbs: e.target.value })} />
          </div>
        )}
        <button className="btn-primary w-full" onClick={submit} disabled={pending || !desc.trim()}>
          {pending ? "Logging…" : manual ? "Log meal" : aiEnabled ? "✨ Estimate & log" : "Estimate & log"}
        </button>
      </div>

      {open && (
        <div className="mt-4 space-y-3 border-t border-line pt-4">
          <div className="flex items-end gap-2">
            <div className="flex-1">
              <label className="label">Calories burned today</label>
              <input className="input" inputMode="numeric" value={burned} onChange={(e) => setBurned(e.target.value)} placeholder="e.g. 350" />
            </div>
            <button className="btn-ghost" onClick={saveBurned} disabled={pending}>Save</button>
          </div>
          {meals.length > 0 && (
            <ul className="space-y-1.5">
              {meals.map((m) => (
                <li key={m.id} className="flex items-center justify-between rounded-xl bg-panel-2 px-3 py-2 text-sm">
                  <div>
                    <div className="font-medium">{m.name} {m.aiEstimated && <span className="text-[10px] text-accent">AI</span>}</div>
                    <div className="text-[11px] text-muted">{m.calories} kcal · P{Math.round(m.protein)} F{Math.round(m.fat)} C{Math.round(m.carbs)}</div>
                  </div>
                  <button className="text-muted hover:text-red-300" onClick={() => start(() => deleteMealAction(m.id))} aria-label="Delete meal">✕</button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </section>
  );
}

function Stat({ label, value, unit, accent }: { label: string; value: number; unit: string; accent?: string }) {
  return (
    <div className="rounded-xl bg-panel-2 px-2 py-2">
      <div className="text-lg font-bold" style={accent ? { color: accent } : undefined}>{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted">{label} · {unit}</div>
    </div>
  );
}
