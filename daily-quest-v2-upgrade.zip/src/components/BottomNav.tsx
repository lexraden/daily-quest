"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const ITEMS = [
  { href: "/today", label: "Today", icon: "⚔️" },
  { href: "/history", label: "History", icon: "📅" },
  { href: "/stats", label: "Stats", icon: "📊" },
  { href: "/profile", label: "Profile", icon: "👤" },
];

export function BottomNav() {
  const path = usePathname();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-panel/90 backdrop-blur" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="mx-auto grid max-w-2xl grid-cols-4">
        {ITEMS.map((it) => {
          const active = path.startsWith(it.href);
          return (
            <Link
              key={it.href}
              href={it.href}
              className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium transition ${active ? "text-white" : "text-muted hover:text-white"}`}
            >
              <span className={`text-xl leading-none ${active ? "scale-110" : ""}`}>{it.icon}</span>
              {it.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
