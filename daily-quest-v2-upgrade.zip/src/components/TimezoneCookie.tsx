"use client";

import { useEffect } from "react";

/** Stores the browser timezone in a cookie so server-side sign-in (Google) can read it. */
export function TimezoneCookie() {
  useEffect(() => {
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (tz) document.cookie = `dq_tz=${encodeURIComponent(tz)}; path=/; max-age=31536000; samesite=lax`;
    } catch {
      /* ignore */
    }
  }, []);
  return null;
}
