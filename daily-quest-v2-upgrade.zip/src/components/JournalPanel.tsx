"use client";

import { useState, useTransition } from "react";
import { addJournalAction, deleteJournalAction } from "@/app/actions/today";
import { useCelebrate } from "./Celebrate";

export function JournalPanel({ entries }: { entries: { id: string; content: string; createdAt: string }[] }) {
  const [text, setText] = useState("");
  const [pending, start] = useTransition();
  const { toast } = useCelebrate();

  const submit = () =>
    start(async () => {
      if (!text.trim()) return;
      try {
        await addJournalAction(text);
        setText("");
        toast("Saved to journal", "success");
      } catch {
        toast("Could not save");
      }
    });

  return (
    <section className="card p-4">
      <h3 className="font-semibold">Journal</h3>
      <textarea className="input mt-3 min-h-20" placeholder="One win, one lesson, one thing you're grateful for…" value={text} maxLength={4000} onChange={(e) => setText(e.target.value)} />
      <button className="btn-ghost mt-2 w-full" onClick={submit} disabled={pending || !text.trim()}>{pending ? "Saving…" : "Add entry"}</button>
      {entries.length > 0 && (
        <ul className="mt-3 space-y-2">
          {entries.map((e) => (
            <li key={e.id} className="group rounded-xl bg-panel-2 px-3 py-2 text-sm">
              <div className="flex items-start justify-between gap-2">
                <p className="whitespace-pre-wrap">{e.content}</p>
                <button className="text-muted opacity-0 transition group-hover:opacity-100 hover:text-red-300" onClick={() => start(() => deleteJournalAction(e.id))} aria-label="Delete entry">✕</button>
              </div>
              <div className="mt-1 text-[11px] text-muted">{new Date(e.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
