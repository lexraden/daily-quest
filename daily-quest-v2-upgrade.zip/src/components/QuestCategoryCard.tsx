"use client";

import { useOptimistic, useTransition } from "react";
import { toggleQuestAction } from "@/app/actions/today";
import { CATEGORY_META, TIER_LABEL, type Category } from "@/lib/game";
import { useCelebrate } from "./Celebrate";

export interface QuestView {
  tier: number;
  emoji: string;
  name: string;
  done: boolean;
}

export function QuestCategoryCard({
  category,
  quests,
  level,
  xp,
}: {
  category: Category;
  quests: QuestView[];
  level: { level: number; progress: number; remaining: number };
  xp: number;
}) {
  const meta = CATEGORY_META[category];
  const { toast, confetti } = useCelebrate();
  const [pending, start] = useTransition();
  const [optimistic, setOptimistic] = useOptimistic(quests, (state, tier: number) => state.map((q) => (q.tier === tier ? { ...q, done: !q.done } : q)));

  const doneCount = optimistic.filter((q) => q.done).length;
  const allDone = doneCount === optimistic.length && optimistic.length > 0;

  const toggle = (tier: number) =>
    start(async () => {
      setOptimistic(tier);
      try {
        const res = await toggleQuestAction(category, tier);
        if (res.done) {
          if (res.levelUp) {
            confetti();
            toast(`Level up! You are now ${res.levelUp}`, "success");
          } else if (res.freezeAwarded) {
            confetti();
            toast(`🧊 ${res.streak}-day streak! You earned a streak freeze`, "success");
          } else if (optimistic.filter((q) => q.done).length + 1 === optimistic.length) {
            confetti();
            toast(`${meta.name} cleared for today! +${tier} XP`, "success");
          } else {
            toast(`+${tier} XP`, "success");
          }
        }
      } catch {
        toast("Could not save. Try again.");
      }
    });

  return (
    <section className={`card overflow-hidden p-4 transition ${allDone ? "ring-1" : ""}`} style={allDone ? { boxShadow: `0 0 0 1px ${meta.color}55, 0 10px 30px -15px ${meta.color}88` } : undefined}>
      <header className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl text-lg" style={{ background: `${meta.color}22` }}>{meta.emoji}</span>
          <div>
            <div className="font-semibold leading-tight" style={{ color: meta.color }}>{meta.name}</div>
            <div className="text-[11px] text-muted">Lv {level.level} · {xp} XP · {level.remaining} to next</div>
          </div>
        </div>
        <div className="text-xs font-medium text-muted">{doneCount}/{optimistic.length}</div>
      </header>
      <div className="mb-3 h-1 w-full overflow-hidden rounded-full bg-panel-2">
        <div className="h-full rounded-full transition-all" style={{ width: `${level.progress}%`, background: meta.color }} />
      </div>
      <ul className="space-y-2">
        {optimistic.map((q) => (
          <li key={q.tier}>
            <button
              type="button"
              disabled={pending}
              onClick={() => toggle(q.tier)}
              className={`flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition ${q.done ? "border-transparent bg-panel-2/60 opacity-70" : "border-line bg-panel-2 hover:border-accent/50"}`}
            >
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs transition"
                style={q.done ? { background: meta.color, borderColor: meta.color, color: "#0b0b14" } : { borderColor: "#3a3a52" }}
              >
                {q.done ? "✓" : ""}
              </span>
              <span className="text-lg leading-none">{q.emoji}</span>
              <span className={`flex-1 text-sm ${q.done ? "line-through" : ""}`}>{q.name}</span>
              <span className="shrink-0 rounded-md bg-bg px-1.5 py-0.5 text-[10px] font-semibold text-muted">{TIER_LABEL[q.tier]} · +{q.tier}</span>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
