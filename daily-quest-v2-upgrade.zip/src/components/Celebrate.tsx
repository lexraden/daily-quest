"use client";

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";

type Toast = { id: number; text: string; tone: "info" | "success" };
type Ctx = { toast: (text: string, tone?: Toast["tone"]) => void; confetti: () => void };

const CelebrateCtx = createContext<Ctx | null>(null);
const COLORS = ["#7c6cf2", "#00cec9", "#fdcb6e", "#ff7675", "#fd79a8", "#00b894"];

export function CelebrateProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [pieces, setPieces] = useState<{ id: number; left: number; color: string; delay: number }[]>([]);

  const toast = useCallback((text: string, tone: Toast["tone"] = "info") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  const confetti = useCallback(() => {
    const batch = Array.from({ length: 40 }, (_, i) => ({ id: Date.now() + i, left: Math.random() * 100, color: COLORS[i % COLORS.length], delay: Math.random() * 0.4 }));
    setPieces((p) => [...p, ...batch]);
    setTimeout(() => setPieces((p) => p.filter((x) => !batch.includes(x))), 2300);
  }, []);

  const value = useMemo(() => ({ toast, confetti }), [toast, confetti]);

  return (
    <CelebrateCtx.Provider value={value}>
      {children}
      {pieces.map((p) => (
        <span key={p.id} className="confetti-piece" style={{ left: `${p.left}%`, background: p.color, animationDelay: `${p.delay}s` }} />
      ))}
      <div className="pointer-events-none fixed inset-x-0 top-4 z-50 flex flex-col items-center gap-2 px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`animate-pop rounded-xl border px-4 py-2 text-sm font-medium shadow-lg backdrop-blur ${t.tone === "success" ? "border-accent/40 bg-accent/20 text-white" : "border-line bg-panel/90 text-white"}`}
          >
            {t.text}
          </div>
        ))}
      </div>
    </CelebrateCtx.Provider>
  );
}

export function useCelebrate(): Ctx {
  const ctx = useContext(CelebrateCtx);
  if (!ctx) return { toast: () => {}, confetti: () => {} };
  return ctx;
}
