"use client";

import { useActionState, useEffect, useState } from "react";
import { loginAction, registerAction, type AuthState } from "@/app/actions/auth";

export function AuthForm({ googleEnabled, initialError }: { googleEnabled: boolean; initialError?: string | null }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [tz, setTz] = useState("UTC");
  const [loginState, login, loginPending] = useActionState<AuthState, FormData>(loginAction, undefined);
  const [registerState, register, registerPending] = useActionState<AuthState, FormData>(registerAction, undefined);

  useEffect(() => {
    try {
      setTz(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
    } catch {
      /* ignore */
    }
  }, []);

  const state = mode === "login" ? loginState : registerState;
  const pending = mode === "login" ? loginPending : registerPending;

  return (
    <div className="card w-full max-w-md p-6 sm:p-8">
      <div className="mb-6 text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-accent/20 text-3xl">⚔️</div>
        <h1 className="text-2xl font-bold">DailyQ</h1>
        <p className="mt-1 text-sm text-muted">Level up your life, one quest a day.</p>
      </div>

      <a
        href={googleEnabled ? "/api/auth/google" : undefined}
        aria-disabled={!googleEnabled}
        className={`btn w-full border border-line bg-white text-slate-900 hover:bg-slate-100 ${googleEnabled ? "" : "cursor-not-allowed opacity-50"}`}
        title={googleEnabled ? "Continue with Google" : "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to enable"}
      >
        <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden>
          <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.6 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.3l7.8 6.1C12.3 13.6 17.7 9.5 24 9.5z" />
          <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z" />
          <path fill="#FBBC05" d="M10.4 28.6A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.6l-7.8-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.7l7.8-6.1z" />
          <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.9 2.3-8.4 2.3-6.3 0-11.7-4.1-13.6-9.9l-7.8 6.1C6.5 42.6 14.6 48 24 48z" />
        </svg>
        Continue with Google
      </a>
      {!googleEnabled && <p className="mt-2 text-center text-xs text-muted">Google sign-in is not configured on this deployment.</p>}

      <div className="my-5 flex items-center gap-3 text-xs text-muted">
        <div className="h-px flex-1 bg-line" /> or with email <div className="h-px flex-1 bg-line" />
      </div>

      <div className="mb-4 grid grid-cols-2 rounded-xl bg-panel-2 p-1 text-sm">
        {(["login", "register"] as const).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMode(m)}
            className={`rounded-lg py-2 font-medium transition ${mode === m ? "bg-accent text-white" : "text-muted hover:text-white"}`}
          >
            {m === "login" ? "Sign in" : "Create account"}
          </button>
        ))}
      </div>

      <form action={mode === "login" ? login : register} className="space-y-3">
        <input type="hidden" name="timezone" value={tz} />
        {mode === "register" && (
          <div>
            <label className="label" htmlFor="name">Name</label>
            <input id="name" name="name" className="input" placeholder="What should we call you?" autoComplete="name" />
          </div>
        )}
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" name="email" type="email" required className="input" placeholder="you@example.com" autoComplete="email" />
        </div>
        <div>
          <label className="label" htmlFor="password">Password</label>
          <input
            id="password"
            name="password"
            type="password"
            required
            minLength={8}
            className="input"
            placeholder={mode === "register" ? "At least 8 characters" : "••••••••"}
            autoComplete={mode === "register" ? "new-password" : "current-password"}
          />
        </div>
        {(state?.error || initialError) && (
          <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{state?.error ?? initialError}</p>
        )}
        <button type="submit" disabled={pending} className="btn-primary w-full">
          {pending ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
        </button>
      </form>
    </div>
  );
}
